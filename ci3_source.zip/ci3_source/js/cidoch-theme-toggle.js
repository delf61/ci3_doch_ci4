/* =========================================================
   CIDOCH THEME TOGGLE
   ========================================================= */

(function () {
    'use strict';

    var KEY = 'cidoch_theme';

    function applyTheme(theme) {
        var root = document.documentElement;
        var button = document.getElementById('cidochThemeToggle');
        var icon = button ? button.querySelector('i') : null;

        if (theme === 'light') {
            root.classList.add('cidoch-light');

            if (icon) {
                icon.className = 'fas fa-moon';
            }

            if (button) {
                button.setAttribute('title', 'Prepnúť na tmavý vzhľad');
                button.setAttribute(
                    'aria-label',
                    'Prepnúť na tmavý vzhľad'
                );
            }
        } else {
            root.classList.remove('cidoch-light');

            if (icon) {
                icon.className = 'fas fa-sun';
            }

            if (button) {
                button.setAttribute('title', 'Prepnúť na svetlý vzhľad');
                button.setAttribute(
                    'aria-label',
                    'Prepnúť na svetlý vzhľad'
                );
            }
        }
    }

    function getSavedTheme() {
        var saved = localStorage.getItem(KEY);

        if (saved === 'light' || saved === 'dark') {
            return saved;
        }

        /* Pri prvom otvorení rešpektuj nastavenie OS. */
        if (
            window.matchMedia &&
            window.matchMedia('(prefers-color-scheme: light)').matches
        ) {
            return 'light';
        }

        return 'dark';
    }

    function initThemeToggle() {
        var button = document.getElementById('cidochThemeToggle');

        if (!button) {
            return;
        }

        applyTheme(getSavedTheme());

        button.addEventListener('click', function () {
            var isLight =
                document.documentElement.classList.contains('cidoch-light');

            var nextTheme = isLight ? 'dark' : 'light';

            localStorage.setItem(KEY, nextTheme);

            applyTheme(nextTheme);
        });
    }

    /* Nastav vzhľad čo najskôr. */
    applyTheme(getSavedTheme());

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            initThemeToggle
        );
    } else {
        initThemeToggle();
    }
})();