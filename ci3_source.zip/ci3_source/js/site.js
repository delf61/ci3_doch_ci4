$(document).ready(function(){

    $("#home a:contains('web.ISyT')").parent().addClass('active');
    $("#seviposta a:contains('sPosta')").parent().addClass('active');
    $("#eviposta a:contains('Pošta')").parent().addClass('active');
    $("#evikalkul a:contains('Kalkulácie')").parent().addClass('active');
    $("#evizak a:contains('Zákazky')").parent().addClass('active');
    $("#team a:contains('Team')").parent().addClass('active');
    $("#doch a:contains('Práce')").parent().addClass('active');
    $("#ulohy a:contains('Úlohy')").parent().addClass('active');
    $("#riadok a:contains('Ria.Dok.')").parent().addClass('active');
    $("#register a:contains('Registre')").parent().addClass('active');

    $("#upload a:contains('Upload')").parent().addClass('active');
    $("#technos a:contains('Technos')").parent().addClass('active');
 
    $('ul.nav li.dropdown').hover(function(){
    
        $('.dropdown-menu', this).fadeIn();
        
        }, function(){    
        
        $('.dropdown-menu', this).fadeOut('fast');
    
    });
});
number_format = function (cislo, decimals, dec_point, thousands_sep) {
    cislo = Number(cislo).toFixed(decimals);

    var nstr = cislo.toString();
    nstr += '';
    x = nstr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? dec_point + x[1] : '';
    var rgx = /(\d+)(\d{3})/;

    while (rgx.test(x1))
        x1 = x1.replace(rgx, '$1' + thousands_sep + '$2');

    return x1 + x2;
};
function flipInt(n){
    var digit, result = 0;
    while( n ){
        digit = n % 10                  //  Get last digit. Ex. 123/10 → 12.3 → 3
        result = (result * 10) + digit  //  Ex. 123 → 1230 + 4 → 1234
        n = n/10|0                      //  Remove last digit. Ex. 123 → 12.3 → 12
    };
    return result;
};
// function sleep(seconds){
//     var waitUntil = new Date().getTime() + seconds*1000;
//     while(new Date().getTime() < waitUntil) true;
// };
// dnes_rmd = function () {
//     var datum = new Date();
//     var d = datum.getDate()+'';
//     var m = datum.getMonth()+1+''; if(datum.getMonth()+1<10){m='0'+m}
//     var r = datum.getFullYear()+'';
//     return r + m + d;
// };