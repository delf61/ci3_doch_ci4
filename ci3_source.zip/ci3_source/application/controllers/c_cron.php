<?php
class C_cron extends CI_Controller {
  // public function __construct(){
  //     parent::__construct();
  //     //$this->load->library('session');
  //     //$this->load->library('database');
  // }
  public function message($to = 'World'){
    echo "Hello {$to}!".PHP_EOL;
  }
  public function vsetko_ok(){
    $this->load->model("M_vsetko_ok");
    $this->M_vsetko_ok->mail_vsetko_ok();
  }
}