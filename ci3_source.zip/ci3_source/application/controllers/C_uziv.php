<?php

class C_uziv extends CI_Controller {
    public function __construct() {
        parent::__construct();
        //kontrola prihlasenia
        if($this->session->userdata('status') != 'login'){
            redirect(base_url().'uvod?msg=nologin');
        }
        $this->load->helper(array("form", "url"));
        $this->load->model("m_uziv");
        $this->load->library(array("form_validation", "session"));
    }
    function get_all(){
        $data = $this->m_uziv->get_all();
        echo json_encode($data);
    }
    function heslo(){
        $this->load->view("site/form_heslo");
    }
    function sav_cel(){
        $i = $this->uri->segment(3);
        $data = array(
            'MENO' => urldecode($this->uri->segment(4)),
            'MESO' => urldecode($this->uri->segment(5)),
            'OD' => urldecode($this->uri->segment(7)),
            'DO' => urldecode($this->uri->segment(8)),
            'ARCINTCIS' => urldecode($this->uri->segment(9))
        ); $this->m_uziv->sav_cel($data,$i);
    }
    function phpAlert($msg) {
        echo '<script type="text/javascript">alert("' . $msg . '")</script>';
    }
    function pandasranda(){
        $this->load->view("uziv/form_hesla");
    }
    function gen_hesla(){
        $array = $this->m_uziv->get_gen_list();
        foreach($array as $u){
            $id = $u->id;
            $length = 8;
            //$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
            $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!_-=+:,.?";
            $password = substr( str_shuffle( $chars ), 0, $length );
            $nove_heslo = $password;

            //$nove_heslo = 'Tec$.'.$u->KOD.'.2O2O';

            $data = array('HESO' => md5($nove_heslo),'ARCINTCIS'=> $nove_heslo);
            // $h = $u->HESO;
            // $data = array('ARCINTCIS'=> md5($h));

            $this->m_uziv->upd_uziv($data,$id);
        }
        $this->load->view('uziv/form_hesla');
    }
    function gen_heste(){
        $array = $this->m_uziv->get_gen_list();
        foreach($array as $u){
            $id = $u->id;
            $length = 8;
            //$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
            $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!_-=+:,.?";
            $password = substr( str_shuffle( $chars ), 0, $length );
            $nove_heslo = $password;

            $nove_heslo = 'Tec$.'.$u->KOD.'.2O2O';

            $data = array('HESO' => md5($nove_heslo),'ARCINTCIS'=> $nove_heslo);
            $this->m_uziv->upd_uziv($data,$id);
        }
        $this->load->view('uziv/form_hesla');
    }
    function heslo_act(){
        $nove_heslo  = $this->input->post('nove_heslo');
        $potvrd_heslo = $this->input->post('potvrd_heslo');
        
        $this->form_validation->set_rules('nove_heslo','nové heslo','min_length[8]|max_length[15]|required|callback_is_password_strong');
        $this->form_validation->set_rules('potvrd_heslo','zopakujte nové heslo','required|matches[nove_heslo]');
        
        if($this->form_validation->run() != false){
            $data = array('HESO' => md5($nove_heslo));
            $i = $this->session->userdata('id');
            //$this->m_rental->update_data($w,$data,'admin');
            $this->m_uziv->upd_uziv($data,$i);
            redirect(base_url().'home?heslo=OK');
            //$this->load->view("site/form_heslo?heslo=OK");
        } else {
            $this->load->view('site/form_heslo');
        }
    }
    function is_password_strong($password){
        if (preg_match('#[0-9]#', $password) && preg_match('#[a-z]#', $password) && 
            preg_match('#[A-Z]#', $password)) {
            return TRUE;
        } else {
            $this->form_validation->set_message("is_password_strong", "{field} musi obsahovať min. 8 znakov, z toho aspoň 1 číslo, 1 malé, 1 veľké písmeno !");
            return FALSE;
        }
    }
    function list(){
        $_SESSION['uziv_skup'] = $this->m_uziv->get_skup();
        $_SESSION['uziv_iso'] = $this->m_uziv->get_iso();
        $_SESSION['uziv_2'] = $this->m_uziv->get_u2();
        $this->load->view("uziv/form_uzivatelia");
    }
    function lista(){
        $a = $this->uri->segment(3);
        $s = $this->uri->segment(4);
        //$data['uzi'] = $this->m_uziv->get_list($a,$s);
        $data = $this->m_uziv->get_list($a,$s);
        echo json_encode($data);
    }
    function listh(){
        $a = $this->uri->segment(3);
        $s = $this->uri->segment(4);
        $data = $this->m_uziv->get_listh($a,$s);
        echo json_encode($data);
    }
    function list1(){
        $a = $this->uri->segment(3);
        $data = $this->m_uziv->get_list1($a);
        echo json_encode($data);
    }
    function login(){
        $this->load->view("uziv/form_login");
    }
    function get_login(){
        $d = $this->uri->segment(3);
        $d = substr($d,6,4).'.'.substr($d,3,2).'.'.substr($d,0,2);
        $data = $this->m_uziv->get_login($d);
        echo json_encode($data);
    }
    function deluziv(){
        $z = $this->uri->segment(3);
        $data = $this->m_uziv->del_uziv($z);
        $_SESSION['uziv_skup'] = $this->m_uziv->get_skup();
        $_SESSION['uziv_iso'] = $this->m_uziv->get_iso();
        $_SESSION['uziv_2'] = $this->m_uziv->get_u2();
    }
    function validation(){
        //$data = $this->m_uziv->del_Veno();
        $_SESSION['ae'] = $this->uri->segment(3);
        //$this->form_validation->set_rules("t1", "prihlasovacie meno", "required|min_length[8]|max_length[10]|trim|alpha_numeric");
        $this->form_validation->set_rules("t1", "prihlasovacie meno", "required|min_length[8]|trim|callback_is_t1_exists");
        $this->form_validation->set_rules("t2", "titul meno priezvisko", "required|min_length[5]|trim|callback_is_t2_exists");
        //$this->form_validation->set_rules("t5", "zaradenie", "required|min_length[5]|trim|callback_is_t5_exists");
        //$this->form_validation->set_rules('t4', 'mail', 'valid_email');
        $this->form_validation->set_rules('skup', 'zaradenie', 'required|callback_is_skup_selected');
        $this->form_validation->set_rules('osc', 'os. číslo z Fingery', 'integer|callback_is_osc_exists');
        $nove_heslo = trim($this->input->post('nove_heslo'));
        if (!empty($nove_heslo)) {
            $this->form_validation->set_rules('nove_heslo', 'nové heslo', 'min_length[8]|max_length[15]|callback_is_password_strong');
        }
        if($this->form_validation->run()){
            $array = array('success' => '<div class="alert alert-success">Thank you for Contact Us</div>');
        }else{
            $array = array(
                'error'   => true,
                't1_error' => form_error('t1'),
                't2_error' => form_error('t2'),
                't4_error' => form_error('t4'),
                'skup_error' => form_error('skup'),
                'osc_error' => form_error('osc'),
                'heslo_error' => form_error('nove_heslo')
            );
        }
        echo json_encode($array);
    }
    function is_skup_selected($value) {
        //echo $value;
        if (!empty($value)) {
            return true;
        } else {
            $this->form_validation->set_message("is_skup_selected", "vyberte {field} !");
            return false;
        }
    }
    function is_t1_exists($value) {
        $i = $this->session->userdata('id');
        //print_r("<br/>" . "<br/>" . "<br/>" . "<br/>".$i);
        
        $t1 = $this->m_uziv->get_all_meso($i);
        // echo "<pre>";
        // print_r($t1);
        // echo "</pre>";
        if (!empty($value)) {
            if (in_array($value, $t1)) {
                $this->form_validation->set_message("is_t1_exists", "toto {field} je už v databáze !"); // zadajte iné prihlasovacie meno
                return false; 
            } else {
                return true;
            }
        } else {
            //$this->form_validation->set_message("is_t1_exists", "{field} je potrebné zadať");
            //return false;
        }
    }
    function is_t2_exists($value) {
        $i = $this->session->userdata('id');
        $t2 = $this->m_uziv->get_all_meno($i);
        if (!empty($value)) {
            if (in_array($value, $t2)) {
                $this->form_validation->set_message("is_t2_exists", "{field} je už v databáze !"); // zadajte iné prihlasovacie meno
                return false; 
            } else {
                return true;
            }
        }
    }
    function is_osc_exists($value) {
        $i = $this->session->userdata('id');
        $osc = $this->m_uziv->get_all_osc($i);
        // echo "<pre>";
        // print_r($osc);
        // echo "</pre>";
        //echo $value;
        if (!empty($value)) {
            if ($value=='0'){
                //$this->form_validation->set_message("is_osc_exists", "{field} nemôže byť 0 !");
                return true; 
            }else{
                // if ($value == null ){
                //     return true;
                // }else{
                    if (in_array($value, $osc)) {
                        $this->form_validation->set_message("is_osc_exists", "toto os. číslo je už v databáze !");
                        return false; 
                    } else {
                        return true;
                    }
                //}
            }
        }
    }
    function check_default($post_string){
        return $post_string == '0' ? FALSE : TRUE;
    }
    function adduziv(){
        $p = $this->uri->segment(3);
        $poz=' ';
        //$prof = '';
        //if($p=='j'){ //$poz='JB';
            $prof = $this->input->post('prof');
        //}
        $s = $this->uri->segment(4);
        $kod = $this->m_uziv->get_kod($s) + 1;
        // echo "<pre>";
        // print_r($kod);
        // echo "</pre>";
        $skup = $this->input->post('skup');
        $skupt = $this->m_uziv->get_skupt($skup);
        $prac = $this->input->post('sel2');
        $prac1 = $this->input->post('sel2a');
        $prac2 = $this->input->post('sel2b');
        $prac3 = $this->input->post('sel2c');
        //var_dump($skup);
        //print_r($skupt);
        $iso = $this->input->post('isofn');
        $isot = '';
        if (!empty($iso)){
            $isot = $this->m_uziv->get_isot($iso);
        };
        $mie = $this->input->post('miesto');
        $t4 = $this->input->post('t3');
        // echo $t1;
        // echo iconv("utf-8", "us-ascii//TRANSLIT", $t1);
        $prevodna_tabulka = Array(
            'ä'=>'a','Ä'=>'A','á'=>'a','Á'=>'A','à'=>'a','À'=>'A','ã'=>'a','Ã'=>'A','â'=>'a','Â'=>'A','č'=>'c','Č'=>'C','ć'=>'c','Ć'=>'C',
            'ď'=>'d','Ď'=>'D','ě'=>'e','Ě'=>'E','é'=>'e','É'=>'E','ë'=>'e','Ë'=>'E','è'=>'e','È'=>'E','ê'=>'e','Ê'=>'E','í'=>'i','Í'=>'I',
            'ï'=>'i','Ï'=>'I','ì'=>'i','Ì'=>'I','î'=>'i','Î'=>'I','ľ'=>'l','Ľ'=>'L','ĺ'=>'l','Ĺ'=>'L','ń'=>'n','Ń'=>'N','ň'=>'n','Ň'=>'N',
            'ñ'=>'n','Ñ'=>'N','ó'=>'o','Ó'=>'O','ö'=>'o','Ö'=>'O','ô'=>'o','Ô'=>'O','ò'=>'o','Ò'=>'O','õ'=>'o','Õ'=>'O','ő'=>'o','Ő'=>'O',
            'ř'=>'r','Ř'=>'R','ŕ'=>'r','Ŕ'=>'R','š'=>'s','Š'=>'S','ś'=>'s','Ś'=>'S','ť'=>'t','Ť'=>'T','ú'=>'u','Ú'=>'U','ů'=>'u','Ů'=>'U',
            'ü'=>'u','Ü'=>'U','ù'=>'u','Ù'=>'U','ũ'=>'u','Ũ'=>'U','û'=>'u','Û'=>'U','ý'=>'y','Ý'=>'Y','ž'=>'z','Ž'=>'Z','ź'=>'z','Ź'=>'Z'
          );
        $t4 = strtoupper(strtr($t4, $prevodna_tabulka));
        $cb1 = 0; if($this->input->post('cb1') == 'on'){$cb1=1;};
        $cb2 = 0; if($this->input->post('cb2') == 'on'){$cb2=1;};
        $cb3 = 0; if($this->input->post('cb3') == 'on'){$cb3=1;};
        $cb4 = 0; if($this->input->post('cb4') == 'on'){$cb4=1;};
        $cb21 = 0; if($this->input->post('cb21') == 'on'){$cb21=1;};
        $cb212 = 0; if($this->input->post('cb212') == 'on'){$cb212=1;};
        $cb22 = 0; if($this->input->post('cb22') == 'on'){$cb22=1;};
        $cb222 = 0; if($this->input->post('cb222') == 'on'){$cb222=1;};
        $cb23 = 0; if($this->input->post('cb23') == 'on'){$cb23=1;};
        $cb232 = 0; if($this->input->post('cb232') == 'on'){$cb232=1;};
        $cb24 = 0; if($this->input->post('cb24') == 'on'){$cb24=1;};
        $cb25 = 0; if($this->input->post('cb25') == 'on'){$cb25=1;};
        $cb31 = 0; if($this->input->post('cb31') == 'on'){$cb31=1;};
        $cb32 = 0; if($this->input->post('cb32') == 'on'){$cb32=1;};
        $cb33 = 0; if($this->input->post('cb33') == 'on'){$cb33=1;};
        $cb34 = 0; if($this->input->post('cb34') == 'on'){$cb34=1;};
        $cb342 = 0; if($this->input->post('cb342') == 'on'){$cb342=1;};
        $cb35 = 0; if($this->input->post('cb35') == 'on'){$cb35=1;};
        // echo $t1;
        //$h = 'Tec$.'.$this->input->post('osc').'.2O2O';

        $length = 8;
        //$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!_-=+:,.?";
        $password = substr( str_shuffle( $chars ), 0, $length );
        $h = $password;
        //$data = array('HESO' => md5($nove_heslo),'ARCINTCIS'=> $nove_heslo);
        $_SESSION['ae'] = $h;
        $_SESSION['pom'] = $this->input->post('t1');
        $poz = '';
        if($cb3==1){$poz='szčo';}
        $data = array(
            'KOD' => $kod,
            'MENO' => $this->input->post('t2'),
            'MESO' => $this->input->post('t1'),
            'HESO' => md5($h),
            'ESO' => $isot,
            'MAIL' => urldecode($this->input->post('t4')),
            'EDIT_ALL' => 0,
            'EDIT_POSTA' => $cb21,
            'EDIT_POST1' => $cb22,
            'EDIT_OP' => 0,
            'EDIT_PRACE' => $cb222,
            'EDIT_KALKU' => $cb23,
            'EDIT_ZAKAZ' => $cb24,
            'EDIT_OBJED' => 0,
            'EDIT_SVOJE' => $cb25,
            'EDIT_UZIVA' => $cb212,
            'EDIT_CHOD_' => 0,
            'EDIT_NASTA' => 0,
            'EDIT_PRIOR' => 0,
            'PRIORITA' => $this->input->post('prio'),
            'ZOBRAZ_LEN' => $cb35,
            'ZOBRAZ_POS' => $cb31,
            'ZOBRAZ_PO1' => $cb32,
            'ZOBRAZ_PRA' => 0,
            'ZOBRAZ_KAL' => $cb33,
            'ZOBRAZ_ZAK' => $cb34,
            'ZOBRAZ_OBJ' => $cb342,
            'ZOBRAZ_CHO' => 0,
            'ZOBRAZ_NAS' => 0,
            'AKTUALIZAC' => 0,
            'AKTUALNY'=> $cb1,
            'AKTIVNY'=> 0,
            'SKUPINA'=> $skupt,
            'POZICIA'=>$poz,
            'POSTAD_DOP'=> 0,
            'POSTAD_PON'=> 0,
            'POSTAD_OBJ'=> 0,
            'POSTAD_VSE'=> 0,
            'POSTAO_DOP'=> 0,
            'POSTAO_PON'=> 0,
            'POSTAO_OBJ'=> 0,
            'POSTAO_VSE'=> 0,
            'PRACE_MENO'=> $this->input->post('t3'),
            'VALIDACIA' => $cb2,
            'ZADAVANIE_' => $cb232,
            'ZOD'=> 0,
            'OS_CISLO'=> $this->input->post('osc'),
            'PRITOMNY'=> 0,
            'AUTO_ZAKAZ'=> 0,
            'AUTO_REZIA'=> $cb4,
            'MENO_ABC'=>$t4,
            'ARCINTCIS'=> $h,
            'KOD_SKU' => $skup,
            'KOD_ISO' => $iso,
            'KOD_PRACE' => $prac,
            'KOD_PRACE1' => $prac1,
            'KOD_PRACE2' => $prac2,
            'KOD_PRACE3' => $prac3,
            'PROFESIA' => $prof
        ); 
        $this->m_uziv->add_uziv($data);
        $_SESSION['uziv_skup'] = $this->m_uziv->get_skup();
        $_SESSION['uziv_iso'] = $this->m_uziv->get_iso();
        $_SESSION['uziv_2'] = $this->m_uziv->get_u2();
    }
    function upduziv(){
        $i = $this->uri->segment(3);
        $skup = $this->input->post('skup');
        $skupt = $this->m_uziv->get_skupt($skup);
        $prac = $this->input->post('sel2');
        $prac1 = $this->input->post('sel2a');
        $prac2 = $this->input->post('sel2b');
        $prac3 = $this->input->post('sel2c');
        //var_dump($skup);
        //print_r($skupt);
        $iso = $this->input->post('isofn');
        $isot = '';
        if (!empty($iso)){
            $isot = $this->m_uziv->get_isot($iso);
        };
        $mie = $this->input->post('miesto');
        $prof = $this->input->post('prof');
        $t4 = $this->input->post('t3');
        $nove_heslo = trim($this->input->post('nove_heslo'));
        // echo $t1;
        // echo iconv("utf-8", "us-ascii//TRANSLIT", $t1);
        $prevodna_tabulka = Array(
            'ä'=>'a','Ä'=>'A','á'=>'a','Á'=>'A','à'=>'a','À'=>'A','ã'=>'a','Ã'=>'A','â'=>'a','Â'=>'A','č'=>'c','Č'=>'C','ć'=>'c','Ć'=>'C',
            'ď'=>'d','Ď'=>'D','ě'=>'e','Ě'=>'E','é'=>'e','É'=>'E','ë'=>'e','Ë'=>'E','è'=>'e','È'=>'E','ê'=>'e','Ê'=>'E','í'=>'i','Í'=>'I',
            'ï'=>'i','Ï'=>'I','ì'=>'i','Ì'=>'I','î'=>'i','Î'=>'I','ľ'=>'l','Ľ'=>'L','ĺ'=>'l','Ĺ'=>'L','ń'=>'n','Ń'=>'N','ň'=>'n','Ň'=>'N',
            'ñ'=>'n','Ñ'=>'N','ó'=>'o','Ó'=>'O','ö'=>'o','Ö'=>'O','ô'=>'o','Ô'=>'O','ò'=>'o','Ò'=>'O','õ'=>'o','Õ'=>'O','ő'=>'o','Ő'=>'O',
            'ř'=>'r','Ř'=>'R','ŕ'=>'r','Ŕ'=>'R','š'=>'s','Š'=>'S','ś'=>'s','Ś'=>'S','ť'=>'t','Ť'=>'T','ú'=>'u','Ú'=>'U','ů'=>'u','Ů'=>'U',
            'ü'=>'u','Ü'=>'U','ù'=>'u','Ù'=>'U','ũ'=>'u','Ũ'=>'U','û'=>'u','Û'=>'U','ý'=>'y','Ý'=>'Y','ž'=>'z','Ž'=>'Z','ź'=>'z','Ź'=>'Z'
          );
        $t4 = strtoupper(strtr($t4, $prevodna_tabulka));
        $cb1 = 0; if($this->input->post('cb1') == 'on'){$cb1=1;};
        $cb2 = 0; if($this->input->post('cb2') == 'on'){$cb2=1;};
        $cb3 = 0; if($this->input->post('cb3') == 'on'){$cb3=1;};
        $cb4 = 0; if($this->input->post('cb4') == 'on'){$cb4=1;};
        $cb21 = 0; if($this->input->post('cb21') == 'on'){$cb21=1;};
        $cb212 = 0; if($this->input->post('cb212') == 'on'){$cb212=1;};
        $cb22 = 0; if($this->input->post('cb22') == 'on'){$cb22=1;};
        $cb222 = 0; if($this->input->post('cb222') == 'on'){$cb222=1;};
        $cb23 = 0; if($this->input->post('cb23') == 'on'){$cb23=1;};
        $cb232 = 0; if($this->input->post('cb232') == 'on'){$cb232=1;};
        $cb24 = 0; if($this->input->post('cb24') == 'on'){$cb24=1;};
        $cb25 = 0; if($this->input->post('cb25') == 'on'){$cb25=1;};
        $cb31 = 0; if($this->input->post('cb31') == 'on'){$cb31=1;};
        $cb32 = 0; if($this->input->post('cb32') == 'on'){$cb32=1;};
        $cb33 = 0; if($this->input->post('cb33') == 'on'){$cb33=1;};
        $cb34 = 0; if($this->input->post('cb34') == 'on'){$cb34=1;};
        $cb342 = 0; if($this->input->post('cb342') == 'on'){$cb342=1;};
        $cb35 = 0; if($this->input->post('cb35') == 'on'){$cb35=1;};
        // echo $t1;
        $poz = '';
        if($cb3==1){$poz='szčo';}
        $data = array(
            //'KOD' => $this->uri->segment(4),
            'MENO' => $this->input->post('t2'),
            'MESO' => $this->input->post('t1'),
            //'HESO'
            'ESO' => $isot,
            'MAIL' => urldecode($this->input->post('t4')),
            'EDIT_ALL' => 0,
            'EDIT_POSTA' => $cb21,
            'EDIT_POST1' => $cb22,
            'EDIT_OP' => 0,
            'EDIT_PRACE' => $cb222,
            'EDIT_KALKU' => $cb23,
            'EDIT_ZAKAZ' => $cb24,
            'EDIT_OBJED' => 0,
            'EDIT_SVOJE' => $cb25,
            'EDIT_UZIVA' => $cb212,
            'EDIT_CHOD_' => 0,
            'EDIT_NASTA' => 0,
            'EDIT_PRIOR' => 0,
            'PRIORITA' => $this->input->post('prio'),
            'ZOBRAZ_LEN' => $cb35,
            'ZOBRAZ_POS' => $cb31,
            'ZOBRAZ_PO1' => $cb32,
            'ZOBRAZ_PRA' => 0,
            'ZOBRAZ_KAL' => $cb33,
            'ZOBRAZ_ZAK' => $cb34,
            'ZOBRAZ_OBJ' => $cb342,
            'ZOBRAZ_CHO' => 0,
            'ZOBRAZ_NAS' => 0,
            'AKTUALIZAC' => 0,
            'AKTUALNY'=> $cb1,
            'AKTIVNY'=> 0,
            'SKUPINA'=> $skupt,
            'POZICIA'=>$poz,
            'POSTAD_DOP'=> 0,
            'POSTAD_PON'=> 0,
            'POSTAD_OBJ'=> 0,
            'POSTAD_VSE'=> 0,
            'POSTAO_DOP'=> 0,
            'POSTAO_PON'=> 0,
            'POSTAO_OBJ'=> 0,
            'POSTAO_VSE'=> 0,
            'PRACE_MENO'=> $this->input->post('t3'),
            'VALIDACIA' => $cb2,
            'ZADAVANIE_' => $cb232,
            'ZOD'=> 0,
            'OS_CISLO'=> $this->input->post('osc'),
            'PRITOMNY'=> 0,
            'AUTO_ZAKAZ'=> 0,
            'AUTO_REZIA'=> $cb4,
            'MENO_ABC'=>$t4,
            'ARCINTCIS'=> 0,
            'KOD_SKU' => $skup,
            'KOD_ISO' => $iso,
            'KOD_PRACE' => $prac,
            'KOD_PRACE1' => $prac1,
            'KOD_PRACE2' => $prac2,
            'KOD_PRACE3' => $prac3,
            'PROFESIA' => $prof
        );
        if (!empty($nove_heslo)) {
            $data['HESO'] = md5($nove_heslo);
            $data['ARCINTCIS'] = $nove_heslo;
        }
        $this->m_uziv->upd_uziv($data,$i);
        $_SESSION['uziv_skup'] = $this->m_uziv->get_skup();
        $_SESSION['uziv_iso'] = $this->m_uziv->get_iso();
        $_SESSION['uziv_2'] = $this->m_uziv->get_u2();
    }
}