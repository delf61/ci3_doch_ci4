<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Uvod extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('m_site');
        $this->load->model('m_uziv');
    }
    
    public function index(){
        $this->load->view('login');
    }
    function login(){
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $this->form_validation->set_rules('username','Username','trim|required');
        $this->form_validation->set_rules('password','Password','trim|required');
        //$this->load->library(array('user_agent', 'custom_library'));
        if($this->agent->is_browser()){
            //echo "<h3>Browser name: ".$this->agent->browser().", Version: ".$this->agent->version()."</h3>";
            $agent = "Browser: ".$this->agent->browser().", ver.: " . $this->agent->version();
        }elseif ($this->agent->is_robot())
        {
            $agent = $this->agent->robot();
        }elseif($this->agent->is_mobile()){
            //echo $this->agent->mobile();
            $agent = $this->agent->mobile();
        }else{$agent = '???';}
        
        $_SESSION['bro'] = $agent;
        $_SESSION['pla'] = $this->agent->platform();
        
        $iplog = $_SERVER['REMOTE_ADDR'];
        $_SESSION['ipa'] = $iplog;
        if ( getenv("HTTP_CLIENT_IP") ) {
            $ip = getenv("HTTP_CLIENT_IP");
        } elseif ( getenv("HTTP_X_FORWARDED_FOR") ) {
            $ip = getenv("HTTP_X_FORWARDED_FOR");
            if ( strstr($ip, ',') ) {
                $tmp = explode(',', $ip);
                $ip = trim($tmp[0]);
            }
        } else {
            $ip = getenv("REMOTE_ADDR");
        }
        $_SESSION['ipb'] = $ip;

        if($this->form_validation->run() != false){
            if($username=='Vie Vénosová'){
                $where = array(
                    'MESO' => $username,
                    'HESO' => md5($password)
                );
            } else {
                $where = array(
                    'MESO' => $username,
                    'HESO' => md5($password)
                );
            }
            $data = $this->m_site->edit_data($where,'_uzivatelia');
            $d = $this->m_site->edit_data($where,'_uzivatelia')->row();
            $cek = $data->num_rows();
            if($cek > 0){
                $ip_ok = 0;
                if($iplog=='::1' || $d->X_IP==1 || $d->MESO=='admin'){
                    $ip_ok = 1;
                }else{
                    $kde = array(
                        'IP'  => $iplog,
                        'KOD' => 0
                    );
                    $daata = $this->m_site->edit_data($kde,'wip_ok');
                    $dd = $this->m_site->edit_data($kde,'wip_ok')->row();
                    $ipr = $daata->num_rows();
                    if($ipr>0){
                        $ip_ok = 1;
                    }else{
                        $kde = array(
                            'IP'  => $iplog,
                            'KOD' => $d->KOD
                        );
                        $daata = $this->m_site->edit_data($kde,'wip_ok');
                        $dd = $this->m_site->edit_data($kde,'wip_ok')->row();
                        $ipr = $daata->num_rows();
                        if($ipr>0){
                            $ip_ok = 1;
                        }
                    }
                }

                if($ip_ok==1){
                    $session = array(
                        'id' => $d->id,
                        'kod' => $d->KOD,
                        'uziv' => $d->MESO,
                        'prac' => $d->MENO,
                        'prace' => $d->PRACE_MENO,
                        'eso' => $d->ESO,
                        'skup' => $d->SKUPINA,
                        'prio' => $d->PRIORITA,
                        'poz' => $d->POZICIA,
                        'zolen' => $d->ZOBRAZ_LEN,
                        'zopos' => $d->ZOBRAZ_POS,
                        'zopo1' => $d->ZOBRAZ_PO1,
                        'zopra' => $d->ZOBRAZ_PRA,
                        'zokal' => $d->ZOBRAZ_KAL,
                        'zozak' => $d->ZOBRAZ_ZAK,
                        'zoobj' => $d->ZOBRAZ_OBJ,
                        'edpos' => $d->EDIT_POSTA,
                        'edpo1' => $d->EDIT_POST1,
                        'edop' => $d->EDIT_OP,
                        'edpra' => $d->EDIT_PRACE,
                        'edkal' => $d->EDIT_KALKU,
                        'edzak' => $d->EDIT_ZAKAZ,
                        'edobj' => $d->EDIT_OBJED,
                        'edlen' => $d->EDIT_SVOJE,
                        'eduzi' => $d->EDIT_UZIVA,
                        'valid' => $d->VALIDACIA,
                        'zod' => $d->ZOD,
                        'status' => 'login'
                    );
                    $this->session->set_userdata($session);
                    $_SESSION['posta'] = 'd';
                    $_SESSION['den'] = strtotime(date('Y-m-d'));
                    $_SESSION['spis'] = '';
                    $_SESSION['cispos'] ='';
                    $_SESSION['ciskal'] ='';
                    $_SESSION['idkal'] ='';
                    $_SESSION['cisobj'] ='';
                    $_SESSION['ciszak'] ='';
                    $_SESSION['idzak'] ='';
                    $_SESSION['file'] = '';
                    $_SESSION['path_to_file'] = '';
                    $_SESSION['pom'] = '';
                    $_SESSION['ae'] = '';
                    $_SESSION['rezia'] = '';
                    $_SESSION['zisk'] = '';
                    $_SESSION['reziap'] = '';
                    $_SESSION['ziskp'] = '';
                    $_SESSION['str'] = 0;
                    $_SESSION['imp'] = 0;
                    $_SESSION['upd'] = 0;
                    $_SESSION['zme'] = 0;
                    $_SESSION['log'] = 0;
                    $_SESSION['d'] = date('Y.m.d');
                    $_SESSION['z'] = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''];
                    $_SESSION['new'] = 1;

                    $data = array(
                        'KOD' => $d->KOD,
                        'DATUM' => date('Y.m.d'),
                        'OD' => date("H:i:s"),
                        'DATUM_DO' => '',
                        'DO' => '+',
                        'AGENT' => $agent,
                        'MENO' => $d->MENO,
                        'PLATFORM' => $_SESSION['pla'],
                        'IP' => $_SESSION['ipa'],
                        'IPB' => $_SESSION['ipb'],
                        'ARCINTCIS' => ''
                    );
                    $this->m_site->insert_data($data,'wuzivlog');

                    $this->load->view("site/site_log");
                    // if($d->SKUPINA!='admin'){
                    //     redirect(site_url('ulohy/list'));
                    // }else{
                    //     redirect(base_url().'c_site/index');
                    // }
                }else{
                    redirect(base_url().'uvod?msg=failip');
                }
            } else {
                $data = array(
                    'KOD' => 0,
                    'DATUM' => date('Y.m.d'),
                    'OD' => date("H:i:s"),
                    //'DATUM_DO' => '',
                    'DO' => '',
                    'AGENT' => $agent,
                    'MENO' => $username,
                    'PLATFORM' => $_SESSION['pla'],
                    'IP' => $_SESSION['ipa'],
                    'IPB' => $_SESSION['ipb'],
                    'ARCINTCIS' => ''
                );
                $this->m_site->insert_data($data,'wuzivlogfake');

                redirect(base_url().'uvod?msg=faillogin');
            }
        } else {
            $this->load->view('login');
        }
    }
    function logout_datcas(){
        $d = urldecode($this->uri->segment(3));
        $c = urldecode($this->uri->segment(4));
        $id = $this->m_uziv->get_last_login1($this->session->userdata('kod'),$_SESSION['d'],$_SESSION['ipa'],$_SESSION['ipb'],$_SESSION['pla']);
        if($id!=0){
            $do = $this->m_uziv->get_last_logout($id);
            if(strlen($do)<8){
                $data = array(
                    "DATUM_DO" => $d,
                    "DO" => $c
                );$this->m_uziv->upd_log($data,$id);
            }
        }
        $id = $this->m_uziv->get_last_login($this->session->userdata('kod'),$_SESSION['d'],$_SESSION['ipa'],$_SESSION['ipb'],$_SESSION['pla']);
        if($id!=0){
            $do = $this->m_uziv->get_last_logout($id);
            if(strlen($do)<8){
                $data = array(
                    "DO" => ''
                );$this->m_uziv->upd_log($data,$id);
            }
        }
        // $s = $this->session->userdata('skup');
        // if($s!='admin'){
        //     redirect(site_url('ulohy/list'));
        // }else{
        //     redirect(base_url().'c_site/index');
        // }
    }
}