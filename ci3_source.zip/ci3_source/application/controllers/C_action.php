<?php

class C_action extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //kontrola prihlasenia
        if($this->session->userdata('status') != 'login'){
            redirect(base_url().'uvod?msg=nologin');
        }
        $this->load->model("m_action");
    }
    public function get_all_data() {

        $data = $this->m_action->select_all_data();
        echo "<pre>";
        print_r($data);
    }
    public function update_data() {

        if ($this->m_action->update_table_data()) {
            echo "<h3>Data has been updated</h3>";
        }
    }
    public function get_users(){
        
        $data = $this->m_action->get_all_users_data();
        echo "<pre>";
        print_r($data);
    }
    public function delete_single_user(){
        
        echo $this->m_action->delete_specific_user();
    }
    public function condition(){
        
        //$data = $this->m_action->get_where_condition_query();
        //$data = $this->m_action->get_and_condition();
        $data = $this->m_action->get_where_in();
        echo "<pre>";
        print_r($data);
    }
    public function get_messages(){
        
        $data = $this->m_action->get_user_messages();
        echo "<pre>";
        print_r($data);
    }
}
