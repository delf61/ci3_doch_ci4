<?php

class Zobraz extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //$this->load->view("include/header");
        //kontrola prihlasenia
        if($this->session->userdata('status') != 'login'){
            redirect(base_url().'uvod?msg=nologin');
        }
        $this->load->helper(array("form", "url"));
        $this->load->model("m_zakazky");
        $this->load->model("m_kalkul");
        $this->load->model("m_site");
        $this->load->model("m_uziv");
    }
    function zakazka(){
        $id = $this->uri->segment(3);
        $_SESSION['idzak'] = $id;
        $id = strrev($id);
        $id = (int)$id / 13;
        $id = $id - 31;
        $id = (int)$id / 31;
        $_SESSION['str'] = 0;
        $_SESSION['zak_zodpo'] = $this->m_uziv->get_zodpo();
        $where = '';
        if($id!=''){ $where = array('id' => $id); }
        $data["evizak"] = $this->m_site->edit_data($where,'wevizak')->result();
        $_SESSION['ciszak'] = $this->m_zakazky->get_cz($id);
        $data['cispos_dop_d'] = $this->m_zakazky->get_cispos_dop_d($_SESSION['ciszak']);
        $data['cispos_obj_d'] = $this->m_zakazky->get_cispos_obj_d($_SESSION['ciszak']);
          echo "<pre>";
          print_r($id);
          echo "</pre>";
        if(count( $data )!=0){
            $this->load->view("zakazky/form_zakazka",$data);
        } else {
            list_zakazky();
        }
    }
    function zakazkaczt(){
        $czt = $this->uri->segment(3);
        $where = '';
        if($czt!=''){ $where = array('CZT' => $czt); }
        $data["evizak"] = $this->m_site->edit_data($where,'wevizak')->result();
        if(count( $data )!=0){
           $this->load->view("zakazky/form_zakazka",$data);
        } else {
           list_zakazky();
        }
    }
    function zakazkac(){
        $c = $this->uri->segment(3);
        $_SESSION['zak_zodpo'] = $this->m_uziv->get_zodpo();
        $where = '';
        if($c!=''){ $where = array('CISZAK' => $c); }
        $data["evizak"] = $this->m_site->edit_data($where,'wevizak')->result();
        if(count( $data )!=0){
           $this->load->view("zakazky/form_zakazka",$data);
        } else {
           list_zakazky();
        }
    }
    function list(){
        $z = $this->uri->segment(3);
        $this->session->set_userdata('pomz', $z );
        $skup = $this->session->userdata('skup');
        $data["evizak"] = $this->m_zakazky->get_zakazky();
        // echo "<pre>";
        // print_r($zakazky);
        // echo "</pre>";
        $data['skup'] = $this->session->userdata('skup');
        $this->load->view("zakazky/form_evizakazky", $data);
    }
    function listb(){
        $z = $this->uri->segment(3);
        $zm = $this->uri->segment(4);
        if($zm=='z'){
            if($_SESSION['zme']==0){$_SESSION['zme']=1;}else{$_SESSION['zme']=0;}
        }
        $this->session->set_userdata('pomz', $z );
        $data = $this->m_zakazky->get_zakazky();
        echo json_encode($data);
    }
    function kalkul(){
        $id = $this->uri->segment(3);
        $_SESSION['idkal'] = $id;
        $_SESSION['zak_zodpo'] = $this->m_uziv->get_zodpo();
        $id = strrev($id);
        $id = (int)$id / 13;
        $id = $id - 31;
        $id = (int)$id / 31;
        $where = '';
        if($id!=0){ $where = array('id' => $id); };
        $data["evikal"] = $this->m_site->edit_data($where,'wevikalkul')->result();
        $_SESSION['ciskal'] = $this->m_kalkul->get_ciskal_id($id);
        $ck = $this->uri->segment(4);
        $data['cispos_dop_d'] = $this->m_kalkul->get_cispos_dop_d($_SESSION['ciskal']);
        $data['cispos_pon_o'] = $this->m_kalkul->get_cispos_pon_o($_SESSION['ciskal']);
        $data['cispos_obj_d'] = $this->m_kalkul->get_cispos_obj_d($_SESSION['ciskal']);
        if(count( $data )!=0){
            $this->load->view("kalkulacie/form_kalkul",$data);
        } else {
            list_kalkul();
        }
    }
    function rekap(){
        $id = $this->uri->segment(3);
        $id = strrev($id);
        $id = (int)$id / 13;
        $id = $id - 31;
        $id = (int)$id / 31;

        $ciskal = $this->m_kalkul->get_ciskal_id($id);
        // $sumrekap = $this->m_kalkul->kapitoly_rek1($ciskal);
        // // echo("</br>"."</br>"."</br>"."</br>"."</br>");
        // // print_r($sumrekap);
        // $s1=0; $s2=0; $s3=0; $s4=0; $s5=0; $s6=0; $s7=0; $s8=0; $s9=0; $s10=0; $s12=0;
        // foreach($sumrekap as $s){
        //     if(substr($s->CAST,0,2)=='01'){$s1=$s1+$s->SPOLU;}
        //     if($s->CAST=='02'){$s2=$s2+$s->SPOLU;}
        //     if($s->CAST=='03'){$s3=$s3+$s->SPOLU;}
        //     if($s->CAST=='04'){$s4=$s4+$s->SPOLU;}
        //     if($s->CAST=='05'){$s5=$s5+$s->SPOLU;}
        //     if($s->CAST=='06'){$s6=$s6+$s->SPOLU;}
        //     if($s->CAST=='07'){$s7=$s7+$s->SPOLU;}
        //     if($s->CAST=='08'){$s8=$s8+$s->SPOLU;}
        //     if($s->CAST=='09'){$s9=$s9+$s->SPOLU;}
        // }
        // $sumrekap = $this->m_kalkul->hod_rek1($ciskal);
        // // echo("</br>"."</br>"."</br>"."</br>"."</br>");
        // // print_r($sumrekap);
        // $p1=0; $p2=0; $p3=0; $p4=0; $p5=0; $p6=0; $p7=0; $p8=0; $p9=0; $p10=0;
        // $h1=0; $h2=0; $h3=0; $h4=0; $h5=0; $h6=0; $h7=0; $h8=0; $h9=0; $h10=0;
        // foreach($sumrekap as $s){
        //     if(substr($s->CAST,0,2)=='01'){$p1=$p1+$s->SPOLU; $h1=$h1+$s->MNOZSTVO;}
        //     if($s->CAST=='02'){$p2=$p2+$s->SPOLU; $h2=$h2+$s->MNOZSTVO;}
        //     if($s->CAST=='03'){$p3=$p3+$s->SPOLU; $h3=$h3+$s->MNOZSTVO;}
        //     if($s->CAST=='04'){$p4=$p4+$s->SPOLU; $h4=$h4+$s->MNOZSTVO;}
        //     if($s->CAST=='05'){$p5=$p5+$s->SPOLU; $h5=$h5+$s->MNOZSTVO;}
        //     if($s->CAST=='06'){$p6=$p6+$s->SPOLU; $h6=$h6+$s->MNOZSTVO;}
        //     if($s->CAST=='07'){$p7=$p7+$s->SPOLU; $h7=$h7+$s->MNOZSTVO;}
        //     if($s->CAST=='08'){$p8=$p8+$s->SPOLU; $h8=$h8+$s->MNOZSTVO;}
        //     if($s->CAST=='09'){$p9=$p9+$s->SPOLU; $h9=$h9+$s->MNOZSTVO;}
        // }
        // $pau1=0;if($h1>0){ $pau1 = $p1 / $h1; };
        // $pau2=0;if($h2>0){ $pau2 = $p2 / $h2; };
        // $pau3=0;if($h3>0){ $pau3 = $p3 / $h3; };
        // $pau4=0;if($h4>0){ $pau4 = $p4 / $h4; };
        // $pau5=0;if($h5>0){ $pau5 = $p5 / $h5; };
        // $pau6=0;if($h6>0){ $pau6 = $p6 / $h6; };
        // $pau7=0;if($h7>0){ $pau7 = $p7 / $h7; };
        // $pau8=0;if($h8>0){ $pau8 = $p8 / $h8; };
        // $pau9=0;if($h9>0){ $pau9 = $p9 / $h9; };
        // $pau10=0;if($h10>0){ $pau10 = $p10 / $h10; };

        // $data = array(
        //     'DOKU_CAS' => $h1,
        //     'DOKU_SUM' => $s1,
        //     'MTZ_CAS' => $h2,
        //     'MTZ_SUM' => $s2,
        //     'VYR_CAS' => $h3,
        //     'VYR_SUM' => $s3,
        //     'KOOP_CAS' => $h4,
        //     'KOOP_SUM' => $s4,
        //     'VLUC_CAS' => $h5,
        //     'VLUC_SUM' => $s5,
        //     'OTK_CAS' => $h6,
        //     'OTK_SUM' => $s6,
        //     'DOPR_CAS' => $h7,
        //     'DOPR_SUM' => $s7,
        //     'OBAL_CAS' => $h8,
        //     'OBAL_SUM' => $s8,
        //     'MONT_CAS' => $h9,
        //     'MONT_SUM' => $s9,
        //     'REZIA_CAS' => $h10,
        //     'REZIA_SUM' => $s10,
        //     //'ZISK' => 0,
        //     //'CELKOM' => 0,
            
        //     'DOKU_PAU' => $pau1,
        //     'MTZ_PAU' => $pau2,
        //     'VYR_PAU' => $pau3,
        //     'KOOP_PAU' => $pau4,
        //     'VLUC_PAU' => $pau5,
        //     'OTK_PAU' => $pau6,
        //     'DOPR_PAU' => $pau7,
        //     'OBAL_PAU' => $pau8,
        //     'MONT_PAU' => $pau9,
        //     'REZIA_PAU' => $pau10,

        //     'DOKU_PAU_S' => $p1,
        //     'MTZ_PAU_SU' => $p2,
        //     'VYR_PAU_SU' => $p3,
        //     'KOOP_PAU_S' => $p4,
        //     'VLUC_PAU_S' => $p5,
        //     'OTK_PAU_SU' => $p6,
        //     'DOPR_PAU_S' => $p7,
        //     'OBAL_PAU_S' => $p8,
        //     'MONT_PAU_S' => $p9,
        //     'REZIA_PAU_' => $p10
        // );
        // $this->m_kalkul->upd_evikal($data,$ciskal);

        $data["evikal"] = $this->m_kalkul->get_evikalkul_1($id);
        
        $this->load->view("kalkulacie/form_rekap",$data);
    }
    function ponobj(){
        $id = $this->uri->segment(3);
        $id = strrev($id);
        $id = (int)$id / 13;
        $id = $id - 31;
        $id = (int)$id / 31;
        $data["evikal"] = $this->m_kalkul->get_evikalkul_1($id);
        $data['cispos_dop_d'] = $this->m_kalkul->get_cispos_dop_d($_SESSION['ciskal']);
        $data['cispos_pon_o'] = $this->m_kalkul->get_cispos_pon_o($_SESSION['ciskal']);
        $data['cispos_obj_d'] = $this->m_kalkul->get_cispos_obj_d($_SESSION['ciskal']);
        $this->load->view("kalkulacie/form_ponobj",$data);
    }
}
?>
