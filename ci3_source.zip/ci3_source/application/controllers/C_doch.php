<?php
class C_doch extends CI_Controller {
    public function __construct() {
        parent::__construct();
        //$this->load->view("include/header");
        //kontrola prihlasenia
        if($this->session->userdata('status') != 'login'){
            redirect(base_url().'uvod?msg=nologin');
        }
        $this->load->helper(array("form", "url"));
        $this->load->model("m_doch");
        $this->load->model("m_site");
//        $this->load->model("m_zakazky");
        $this->load->model("m_uziv");
        $this->load->library(array("form_validation", "session"));

        $this->load->library('Pdf_Library');

        $prefs = array(
            'start_day'    => 'monday',
            'month_type'   => 'short',
            'day_type'     => 'short',
            'show_next_prev' => true
        );
        $this->load->library('calendar', $prefs);
    }

    function get_doch_den(){
        $d = $this->uri->segment(3);
        $iu = $this->uri->segment(4);
        if(strlen($d)==10){$_SESSION['den'] = strtotime($d);};
        $dni = cal_days_in_month(CAL_JULIAN,substr($d,3,2),substr($d,6,4));
        // if($iu==0){
            $data = $this->m_doch->get_1_den($d, $iu);
        // }else{

        // }
        echo json_encode($data);
    }

    function phf_report() {
        $xv = $this->uri->segment(3);
        $_SESSION['zme'] = 0;
        $data["prac"] = $this->m_doch->get_uziv_data($_SESSION['idzak']);

        $this->db->truncate('wdoch_tlac');
        $mes = $this->m_doch->get_1($_SESSION['idzak'], $xv);
        foreach ($mes as $q){
            $this->m_doch->add_1_den_1_prac_tlac($q);
            if($_SESSION['idkal'] != 1){
                $den = array(
                    'PRICHOD' => '-',
                    'ODCHOD' => '-',
                    'HODINY' => 0,
                    'POZN' => ' '
                ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                if($q->MIESTO != 0){
                    $denhod = $this->m_doch->get_1_den($q->DATUM, $q->id_uziv);
                    foreach ($denhod as $r){
                        if($r->id_miesto == 1){
                            $den = array(
                                'PRICHOD' => $r->OD,
                                'ODCHOD' => $r->DO,
                                'HODINY' => $r->HODINY,
                                'POZN' => 'had'
                            ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                        }
                    }
                }
            } else {
                if($q->MIESTO != 0){
                    $denhod = $this->m_doch->get_1_den($q->DATUM, $q->id_uziv);
                    foreach ($denhod as $r){
                        $den = array(
                            'PRICHOD' => '-',
                            'ODCHOD' => '-',
                            'HODINY' => 0,
                            'POZN' => ' '
                        ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                        if($r->id_miesto == 1){
                            $den = array(
                                'PRICHOD' => $r->OD,
                                'ODCHOD' => $r->DO,
                                'HODINY' => $r->HODINY,
                                'POZN' => 'had'
                            ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                        }
                    }
                }
            }
        }
        $data["doch"] = $this->m_doch->get_tlac();

        $data["vypl"] = $this->m_doch->get_mes_vypl($_SESSION['idzak']);

        $this->load->view("doch/form_rpt", $data);
    }
    
    function pdf_report() {
        $xv = $this->uri->segment(3);
        $_SESSION['zme'] = 1;
        $data["prac"] = $this->m_doch->get_uziv_data($_SESSION['idzak']);
        $this->db->truncate('wdoch_tlac');
        $mes = $this->m_doch->get_1($_SESSION['idzak'], $xv);
        foreach ($mes as $q){
            $this->m_doch->add_1_den_1_prac_tlac($q);
            if($_SESSION['idkal'] == 1){
                $den = array(
                    'PRICHOD' => '-',
                    'ODCHOD' => '-',
                    'HODINY' => 0,
                    'POZN' => ' '
                ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                if($q->MIESTO != 0){
                    $denhod = $this->m_doch->get_1_den($q->DATUM, $q->id_uziv);
                    foreach ($denhod as $r){
                        if($r->id_miesto == 2 || $r->id_miesto == 3){
                            $den = array(
                                'PRICHOD' => $r->OD,
                                'ODCHOD' => $r->DO,
                                'HODINY' => $r->HODINY,
                                'POZN' => 'danica'
                            ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                        }
                    }
                }
            } else {
                if($q->MIESTO != 0){
                    $den = array(
                        'POZN' => 'dan. DN+ZV'
                    ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                    // $denhod = $this->m_doch->get_1_den($q->DATUM, $q->id_uziv);
                    // foreach ($denhod as $r){
                    //     $den = array(
                    //         'PRICHOD' => '-',
                    //         'ODCHOD' => '-',
                    //         'HODINY' => 0,
                    //         'POZN' => ' '
                    //     ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                    //     if($r->id_miesto == 2 || $r->id_miesto == 3){
                    //         $den = array(
                    //             'PRICHOD' => $r->OD,
                    //             'ODCHOD' => $r->DO,
                    //             'HODINY' => $r->HODINY,
                    //             'POZN' => 'danica'
                    //         ); $this->m_doch->upd_1_den_1_prac_tlac($den, $q->id);
                    //     }
                    // }
                }
            }
        }
        $data["doch"] = $this->m_doch->get_tlac();
        $data["vypl"] = $this->m_doch->get_mes_vypl($_SESSION['idzak']);
        $this->load->view("doch/form_rpt", $data);
    }
    
    function get_doch(){
        $d = $this->uri->segment(3);
        $iu = $this->uri->segment(4);
        $vypl = $this->uri->segment(5);

        $_SESSION['idzak'] = $iu;  // kod uz.
        
        if(strlen($d)==10){
            $_SESSION['den'] = strtotime($d);
        };
        $dni = cal_days_in_month(CAL_JULIAN,substr($d,3,2),substr($d,6,4));
        if($iu == 0){
            $daata = $this->m_doch->get_all($d, $vypl);
        }else{
            $ok = 0;
            $data = $this->m_uziv->get_1($iu, $vypl);
            // print_r($dni);
            foreach ($data as $q){

                $_SESSION['idkal'] = $q -> id_miesto;      // kod primarneho miesta uz.

                $u_od_s = $q->OD;
                $u_od = substr($u_od_s,0,4).substr($u_od_s,5,2);
                $u_od = $u_od + 0;
                $u_oddo = substr($d,6,4).substr($d,3,2);
                $u_oddo = $u_oddo + 0;
                $u_do_s = $q->DO;
                $u_do = substr($u_do_s,0,4).substr($u_do_s,5,2);

                // print_r($u_do);

                // if (is_string($u_do)) { $u_do = (int)$u_do; }

                if($u_do_s!=''){$u_do = (int)$u_do + 0;}else{$u_do = 0;}
                $ok = 0;
                if($u_oddo>= $u_od){
                    if($u_oddo<= $u_do){$ok=1;}
                    if($u_do_s==''){$ok=1;}
                }
            }
            if($ok==1){
                $this->db->select("*");
                $this->db->where("substr(DATUM, 4, 7)=", substr($d,3,7));
                $this->db->where("id_uziv", $iu);
                $dni_1 = $this->db->get("wdoch");
                $a = $dni_1->num_rows();
                //print_r($dni . '   ' . $a);
                if($a<$dni){
                    $i = 1; 
                    while ($i < ($dni + 1)){
                        $this->db->select("*");
                        $si = $i;
                        if($i<10){$si = '0'.$i;}
                        $this->db->where("DATUM=", $si.'.'.substr($d,3,7));
                        $this->db->where("id_uziv", $iu);
                        $dni_1 = $this->db->get("wdoch");

                        $a = $dni_1->num_rows();
                        if($a==1){
                            foreach ($dni_1 as $q){
                                $u_obed = $q->OBED;
                            }
                        }

                        //print_r($dni_1);
                        $a = $dni_1->num_rows();
                        //print_r($a);
                        if($a==0){
                            $sv = 0;
                            $pozn = '';
                            $this->db->where("DATUM=", $si.'.'.substr($d,3,2));
                            $svia = $this->db->get("wsviatky");
                            $a = $svia->num_rows();
                            if($a==1){
                                $this->db->where("DATUM=", $si.'.'.substr($d,3,2));
                                $svia = $this->db->get("wsviatky")->result();
                                foreach ($svia as $q){
                                    $pozn = $q->T;
                                    $sv = 1;
                                }
                            }
                            $vp = $si-1;
                            $this->db->where("VELNOC=", $vp.'.'.substr($d,3,2));
                            $this->db->where("ROK=", substr($d,6,4));
                            $svia = $this->db->get("velnoc");
                            $a = $svia->num_rows();
                            if($a==1){
                                $this->db->where("VELNOC=", $vp.'.'.substr($d,3,2));
                                $this->db->where("ROK=", substr($d,6,4));
                                $svia = $this->db->get("velnoc")->result();
                                foreach ($svia as $q){
                                    $pozn = 'Veľkonočný pondelok';
                                    $sv = 1;
                                }
                                if($vp>3){
                                    $vp = $si-3;
                                    $spi = $vp;
                                    if($vp<10){$spi = '0'.$vp;}
                                    $vp = $spi.'.'.substr($d,3,7);
                                }else{
                                    if($vp=3){ $vp = 31; }
                                    if($vp=2){ $vp = 30; }
                                    if($vp=1){ $vp = 29; }
                                    $vp = $vp.'.03.'.substr($d,6,4);
                                }
                                $data = array('POZN' => 'Veľký piatok',
                                            'SVIATOK' => $sv);
                                $this->m_doch->upd_doch($data, $id_u, $vp);
                            }
                            $wd = date('w', strtotime($si.'.'.substr($d,3,7)));
                            if($wd==0){$wd='Ne';}
                            if($wd==1){$wd='Po';}
                            if($wd==2){$wd='Ut';}
                            if($wd==3){$wd='St';}
                            if($wd==4){$wd='št';}
                            if($wd==5){$wd='Pi';}
                            if($wd==6){$wd='So';}
                            //print_r($i);
                            $den = array(
                                'id_uziv' => $iu,
                                'DATUM' => $si.'.'.substr($d,3,7),
                                'DEN' => $wd,
                                'PRICHOD' => '',
                                'ODCHOD' => '',
                                'POZN' => $pozn,
                                'DAT' => substr($d,6,4).'.'.substr($d,3,2).'.'.$si,
                                // 'TRVANIE' => $h,
                                'SVIATOK' => $sv,
                                'OBED' => 0,
                                'HODINY' => 0,
                                'NADCAS' => 0,
                                'ARCINTCIS' => ''
                            ); $this->m_doch->add_1_den_1_prac($den);
                        }
                        $i++;
                    }
                }
            }
            $daata = $this->m_doch->get_1($iu, $vypl);
            // $_SESSION['upd'] = 0;
            // if($vypl != 'x'){ $this->m_doch->get_spolu($iu, $d); }
        }
        echo json_encode($daata);
    }
    function generuj_doch(){
        $this->db->truncate('wdoch');
        $d = $this->uri->segment(3);
        $iu = $this->uri->segment(4);

        $rok = substr($d,6,4);
        $mes = substr($d,3,2);
        while ($rok != '2024'){
            //print_r($d);
            if(strlen($d)==10){$_SESSION['den'] = strtotime($d);};
            $dni = cal_days_in_month(CAL_JULIAN, $mes, $rok);
            if($iu == 0){
                $data = $this->m_uziv->get_all();
                //print_r($dni);
                foreach ($data as $q){
                    $id_u = $q->id;
                    //if($id_u==2){
                        $u_od_s = $q->OD;
                        $u_od = substr($u_od_s,0,4).substr($u_od_s,5,2);
                        $u_od = $u_od + 0;
                        $u_oddo = substr($d,6,4).substr($d,3,2);
                        $u_oddo = $u_oddo + 0;
                        $u_do_s = $q->DO;
                        $u_do = substr($u_do_s,0,4).substr($u_do_s,5,2);

                        // if (is_string($u_do)) { $u_do = (int)$u_do; }

                        if($u_do_s!=''){$u_do = $u_do + 0;}else{$u_do = 0;}
                        //print_r('od_' . $u_od . ' do_' . $u_do . ' do_s' . $u_do_s . ' dd_' . $u_oddo . '.....');
                        $ok = 0;
                        if($u_oddo>= $u_od){
                            //print_r(' dd_' . $u_oddo . '  od_'.$u_od . '......' );
                            if($u_oddo<= $u_do){$ok=1;} //print_r('do_x_' . $u_do . '......' . $u_do_s . '......' );}
                            if($u_do_s==''){$ok=1;} //print_r('do_0_' . $u_do . '......' . $u_do_s . '......' );}
                        }
                        if($ok==1){
                            $this->db->select("*");
                            $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
                            $this->db->where("id", $id_u);
                            $dni_1 = $this->db->get("wdoch");
                            //print_r($dni_1);
                            $a = $dni_1->num_rows();
                            //print_r($a);
                            if($a==0){
                                $i = 1; 
                                while ($i < ($dni + 1)){
                                    $si = $i;
                                    if($i<10){$si = '0'.$i;}
                                    $wd = date('w', strtotime($si.'.'.substr($d,3,7)));
                                    //print_r($si.'.'.substr($d,3,7));
                                    $sv = 0;
                                    $pozn = '';
                                    $this->db->where("DATUM=", $si.'.'.substr($d,3,2));
                                    $svia = $this->db->get("wsviatky");
                                    $a = $svia->num_rows();
                                    if($a==1){
                                        $this->db->where("DATUM=", $si.'.'.substr($d,3,2));
                                        $svia = $this->db->get("wsviatky")->result();
                                        foreach ($svia as $q){
                                            $pozn = $q->T;
                                            $sv = 1;
                                        }
                                    }
                                    $vp = $si-1;
                                    $this->db->where("VELNOC=", $vp.'.'.substr($d,3,2));
                                    $this->db->where("ROK=", substr($d,6,4));
                                    $svia = $this->db->get("velnoc");
                                    $a = $svia->num_rows();
                                    if($a==1){
                                        $sv = 1;
                                        $this->db->where("VELNOC=", $vp.'.'.substr($d,3,2));
                                        $this->db->where("ROK=", substr($d,6,4));
                                        $svia = $this->db->get("velnoc")->result();
                                        foreach ($svia as $q){ $pozn = 'Veľkonočný pondelok';}

                                        if($vp>3){
                                            $vp = $si-3;
                                            $spi = $vp;
                                            if($vp<10){$spi = '0'.$vp;}
                                            $vp = $spi.'.'.substr($d,3,7);
                                        }else{
                                            if($vp=3){ $vp = 31; }
                                            if($vp=2){ $vp = 30; }
                                            if($vp=1){ $vp = 29; }
                                            $vp = $vp.'.03.'.substr($d,6,4);
                                        }
                                        $data = array('POZN' => 'Veľký piatok',
                                                    'SVIATOK' => $sv);
                                        $this->m_doch->upd_doch($data, $id_u, $vp);
                                    }
                                    $pri='07:30';
                                    $odch='16:00';
                                    $hod=8;
                                    $ob = 0;
                                    if($id_u==2){$ob = 1;}
                                    if($id_u==3){$pri='07:00';$odch='12:00';$hod=5;}
                                    if($id_u==4){
                                        $ob = 1;
                                        if($wd==4){$pri='';$odch='';$hod=0;$ob = 0;}
                                    }
                                    if($id_u==5){
                                        if($wd!=4)
                                            {$pri='';$odch='';$hod=0;$ob = 0;}
                                        else
                                            {$pri='07:30';$odch='16:00';$hod=8;$ob = 1;}
                                    }
                                    $pri='';$odch='';$hod=0;$ob = 0;  // !!!!
                                    if($wd==0){$wd='Ne';$pri='';$odch='';$hod=0;$ob = 0;}
                                    if($wd==1){$wd='Po';}
                                    if($wd==2){$wd='Ut';}
                                    if($wd==3){$wd='St';}
                                    if($wd==4){$wd='Št';}
                                    if($wd==5){$wd='Pi';}
                                    if($wd==6){$wd='So';$pri='';$odch='';$hod=0;$ob = 0;}
                                    if($sv==1){$pri='';$odch='';$hod=0;$ob = 0;}
                                    //print_r($i);
                                    if($id_u==6){$pri='';$odch='';$hod=0;$ob = 0;}
                                    if($id_u==9){$pri='';$odch='';$hod=0;$ob = 0;}
                                    if($id_u==11){$pri='';$odch='';$hod=0;$ob = 0;}
                                    $den = array(
                                        'id_uziv' => $id_u,
                                        'DATUM' => $si.'.'.substr($d,3,7),
                                        'DEN' => $wd,
                                        'PRICHOD' => $pri,
                                        'ODCHOD' => $odch,
                                        'POZN' => $pozn,
                                        'DAT' => substr($d,6,4).'.'.substr($d,3,2).'.'.$si,
                                        'SVIATOK' => $sv,
                                        'OBED' => $ob,
                                        'HODINY' => $hod,
                                        'NADCAS' => 0,
                                        'ARCINTCIS' => ''
                                    ); $this->m_doch->add_1_den_1_prac($den);
                                
                                    $i++;
                                }
                            }
                        }
                    //}
                }
            }else{
            
            }
            if($mes=='01'){
                $rok = $rok - 1;
                $mes = '12';
                $d = '01.'.$mes.'.'.$rok;
                $_SESSION['den'] = strtotime($d);
            }else{
                $mes = $mes-1;
                $si = $mes;
                if($mes<10){$si = '0'.$mes;}
                $d = '01.'.$si.'.'.$rok;
                $_SESSION['den'] = strtotime($d);
            }
        }
        $d = $this->uri->segment(3);
        if(strlen($d)==10){$_SESSION['den'] = strtotime($d);};
        
        $daata = $this->m_doch->get_all();
        
        echo json_encode($daata);
    }
    
    function get_mes_vypl(){
        $d = $this->uri->segment(3);
        if(strlen($d)==10){
            $_SESSION['den'] = strtotime($d);
        };
        $id_uziv = $this->uri->segment(4);
        $this->db->select("id");
        $this->db->where("id_uziv=", $id_uziv);
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $x = $this->db->get("wvypl_hod")->num_rows();
        if($x==1){
            $data = $this->m_doch->get_mes_vypl($id_uziv);
            echo json_encode($data);
        } else {
            echo null;
        }
    }
    function uloz_mes_vypl(){
        set_time_limit(0);
        $d = $this->uri->segment(3);
        if(strlen($d)==10){
            $_SESSION['den'] = strtotime($d);
        };
        $rok = substr($d,6,4);
        $mes = substr($d,3,2);
        $pom = (int)$mes;
        if($pom<10){$si = '0'.$mes;}
        $id_u = $this->uri->segment(4);

        $this->db->select("id");
        $this->db->where("id_uziv=", $id_u);
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $x = $this->db->get("wvypl_hod")->num_rows();
        if($x==1){
            $this->db->select("id");
            $this->db->where("id_uziv=", $id_u);
            $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
            $y = $this->db->get("wvypl_hod")->result();
            foreach ($y as $q){ $id = $q->id;}
            $data = array(
                'HODINY' => $this->input->post('lek_vypl'),
                'HODINY_DOVOL' => $this->input->post('dov_vypl'),
                'HODINY_NV' => $this->input->post('nv_vypl'),
                'HODINY_PN' => $this->input->post('pn_vypl'),
                'HODINY_LEKAR' => $this->input->post('nlek_vypl'),
                'HODINY_OCR' => $this->input->post('ocr_vypl')
            );
            $this->m_doch->upd_mes_vypl($data, $id);
        } else {
            $data = array(
                'id_uziv' => $id_u,
                'DATUM'  => $d,
                // 'POZN'   => $pozn,
                'HODINY' => $this->input->post('lek_vypl'),
                'HODINY_DOVOL' => $this->input->post('dov_vypl'),
                'HODINY_NV' => $this->input->post('nv_vypl'),
                'HODINY_PN' => $this->input->post('pn_vypl'),
                'HODINY_LEKAR' => $this->input->post('nlek_vypl'),
                'HODINY_OCR' => $this->input->post('ocr_vypl')
            );
            $this->m_doch->add_mes_vypl($data);
        }

        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }   
    function generuj_doch_vypl(){
        set_time_limit(0);
        $d = $this->uri->segment(3);
        $rok = substr($d,6,4);
        $mes = substr($d,3,2);
        $den_y_m_d = $this->input->post('datum_od_vypl');
        $den_y_m_d = $this->input->post('d_o_v');
        
        $den_d = $this->input->post('d_o_v');
        
        $_SESSION['ae'] = (string)$den_d;

        $id_u = $this->uri->segment(4);
        $cin = $this->uri->segment(5);
        $i = 1; $j = 0; $ok = 0;
        while ($j < 2){
            if($j == 0){
                $si = '';
                if($i<10){$si = '0'.(string)$i.'.';}else{$si = $i.'.';}
                $den = $si . substr($den_y_m_d,3,7);
                $dnik = $this->m_doch->get_den_uzi_vypl($den,$id_u);
                    
                foreach ($dnik as $q){
                    $den_id = $q->id;
                    $den_v_tyz = $q->DEN;
                    $den_svia = $q->SVIATOK;
                
                    if($den == $den_d){
                        $ok = 1;
                    }
                }
                $j = 1;
                if($den_y_m_d == $this->input->post('d_d_v')){
                    $j = 2;
                }
            
            } else {
                $si = '';
                if($i<10){$si = '0'.(string)$i.'.';}else{$si = $i.'.';}
                $den = $si . substr($den_y_m_d,3,7);

                if($i == 2){
                    // $j = 2;
                }

                // $_SESSION['ae'] = $den;

                $dnik = $this->m_doch->get_den_uzi_vypl($den,$id_u);
                    
                foreach ($dnik as $q){
                    $den_id = $q->id;
                    $den_v_tyz = $q->DEN;
                    $den_svia = $q->SVIATOK;
                    
                    if($den == $den_d){
                        $ok = 1;
                    }
                }
                if($si . substr($den,3,7) == $this->input->post('d_d_v')){
                    $j = 2;
                }
        
            }
            $pozn = '';
            if($ok == 1){
                if($den_v_tyz == 'So' || $den_v_tyz == 'Ne' || $den_svia == 1){
                    if($den_svia == 1){ $pozn = 'sviatok'; }
                    $data = array(
                        'PRICHOD' => $this->input->post(''),
                        'ODCHOD'  => $this->input->post(''),
                        'POZN'   => $pozn,
                        'HODINY' => $this->input->post('0'),
                        'HODINY_DN' => 0
                    ); 
                } else {
                    if($cin == 8){ $pozn = 'dovolenka'; };
                    if($cin == 14){ $pozn = 'NV'; };
                    if($cin == 9){ $pozn = 'PN'; };
                    if($cin == 10){ $pozn = 'lekár'; };
                    if($cin == 7){ $pozn = 'OČR'; };
                    $pozn = $pozn . ' ' . $this->input->post('textarea_hod_vypl');
                    if($den_svia == 1){ $pozn = 'sviatok  ' . $pozn; };
                    $od = '';
                    $do = '';
                    $hod = 0;
                    if($cin == 1){ // lekaren
                        $od = $this->input->post('hodiny_od_vypl');
                        $do = $this->input->post('hodiny_do_vypl');
                        $m_od = (int)substr($od,3,2) / 60; $h_od = (int)substr($od,0,2);
                        $m_do = (int)substr($do,3,2) / 60; $h_do = (int)substr($do,0,2);
                        $hod = (($h_do + $m_do) - ($h_od + $m_od));
                        $obed = 0;
                        if($hod > 4.5){ $hod = $hod - 0.5; }
                    }
                    
                    $data = array(
                        'PRICHOD' => $od,
                        'ODCHOD'  => $do,
                        'POZN'   => $pozn,
                        'HODINY' => $hod,
                        'HODINY_DN' => $cin
                    );
                    // echo $hod;
                }
                $this->m_doch->upd_doch_vypl($data, $den_id);
            }
            $i++;
            if($i > 31){ $j = 2;}
        }
        $uzi = $this->m_doch->get_uziv_data($id_u);
        foreach ($uzi as $u){
            $hod_uzi = $u->ARCINTCIS;
        }
        $_SESSION['den'] = strtotime($d);
        $this->db->select("*");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->order_by('DAT', 'ASC');
        $daata=$this->db->get("wdoch_vypl")->result();

        $hod = 0; $hod_7 = 0; $hod_8 = 0; $hod_9 = 0; $hod_10 = 0; $hod_14 = 0;
        foreach ($daata as $g){ 
            $cin = $g->HODINY_DN;
            // echo $cin."<br>";
            if($cin == 1){ 
                $hod = $hod + $g->HODINY;
            } else {
                if($hod_uzi > 0){
                    if($cin == 8) { $hod_8  = $hod_8  + $hod_uzi; };
                    if($cin == 14){ $hod_14 = $hod_14 + $hod_uzi; };
                    if($cin == 9) { $hod_9  = $hod_9  + $hod_uzi; };
                    if($cin == 10){ $hod_10 = $hod_10 + $hod_uzi; };
                    if($cin == 7) { $hod_7  = $hod_7  + $hod_uzi; };
                }
            }
        }
        $this->db->select("id");
        $this->db->where("id_uziv=", $id_u);
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));

        // echo date('m.Y', $_SESSION['den']);

        $x = $this->db->get("wvypl_hod")->num_rows();
        if($x==1){
            $this->db->select("id");
            $this->db->where("id_uziv=", $id_u);
            $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
            $y = $this->db->get("wvypl_hod")->result();
            foreach ($y as $z){ $id = $z->id;}

            // echo ' ' . $id;

            $data = array(
                'HODINY' => $hod,
                'HODINY_DOVOL' => $hod_8,
                'HODINY_NV' => $hod_14,
                'HODINY_PN' => $hod_9,
                'HODINY_LEKAR' => $hod_10,
                'HODINY_OCR' => $hod_7
                // 'HODINY' => $this->input->post('lek_vypl'),
                // 'HODINY_DOVOL' => $this->input->post('dov_vypl'),
                // 'HODINY_NV' => $this->input->post('nv_vypl'),
                // 'HODINY_PN' => $this->input->post('pn_vypl'),
                // 'HODINY_LEKAR' => $this->input->post('nlek_vypl'),
                // 'HODINY_OCR' => $this->input->post('ocr_vypl')
            );
            $this->m_doch->upd_mes_vypl($data, $id);
        }

        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }

    function sav_cel(){
        $i = $this->uri->segment(3);
        $stl = $this->uri->segment(4);
        $d = urldecode($this->uri->segment(5));
        
        if($stl=='E'){
            $od = $this->m_doch->get_odch($i);
            $m_od = (int)substr($od,3,2) / 60; $h_od = (int)substr($od,0,2);
            $m_pr = (int)substr($d,3,2) / 60;  $h_pr = (int)substr($d,0,2);
            $hod = (($h_od + $m_od) - ($h_pr + $m_pr));
            $data = array(
                'PRICHOD' => $d,
                'HODINY' => $hod
            );
        }
        if($stl=='F'){
            $pr = $this->m_doch->get_prich($i);
            $m_od = (int)substr($d,3,2) / 60;  $h_od = (int)substr($d,0,2);
            $m_pr = (int)substr($pr,3,2) / 60; $h_pr = (int)substr($pr,0,2);
            $hod = (($h_od + $m_od) - ($h_pr + $m_pr));
            $data = array(
                'ODCHOD' => $d,
                'HODINY' => $hod
            );
        }
        if($stl=='G'){
            $data = array(
                'POZN' => $d
            );
        } $this->m_doch->sav_cel($data,$i);
    }
    function get_uziv_data(){
        $id = $this->uri->segment(3);
        $data = $this->m_doch->get_uziv_data($id);
        echo json_encode($data);
    }
    function get_mie_data(){
        $id = $this->uri->segment(3);
        $data = $this->m_doch->get_mie_data($id);
        echo json_encode($data);
    }

    function add_hod(){
        $d = $this->uri->segment(3);
        $data = array(
            'id_uziv' => $this->uri->segment(4),
            'id_miesto' => $this->uri->segment(5),
            'DATUM'  => $d,
            'OD'     => $this->input->post('hodiny_od'),
            'DO'     => $this->input->post('hodiny_do'),
            'POZN'   => $this->input->post('textarea_hod'),
            'DAT'    => substr($d,6,4).'.'.substr($d,3,2).'.'.substr($d,0,2),
            'HODINY' => $this->uri->segment(6)
        ); 
        $this->m_doch->add_hod($data);
        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }
    function upd_hod(){
        $d = $this->uri->segment(3);
        $data = array(
            'id_uziv' => $this->uri->segment(4),
            'id_miesto' => $this->uri->segment(5),
            'DATUM'  => $d,
            'OD'     => $this->input->post('hodiny_od'),
            'DO'     => $this->input->post('hodiny_do'),
            'POZN'   => $this->input->post('textarea_hod'),
            'DAT'    => substr($d,6,4).'.'.substr($d,3,2).'.'.substr($d,0,2),
            'HODINY' => $this->uri->segment(6)
        ); 
        $i = $this->uri->segment(7);
        $this->m_doch->upd_hod($data, $i);
        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }
    function upd_den_pozn(){
        $d = $this->uri->segment(3);
        $id_uziv = $this->uri->segment(4);
        $id = $this->uri->segment(5);
        $data = array(
            'POZN'   => $this->input->post('textarea')
        ); $this->m_doch->upd_den_1_prac_pozn($id_uziv, $id, $data);
        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }
    function upd_den(){
        $d = $this->uri->segment(3);
        $id_uziv = $this->uri->segment(4);
        $id = $this->uri->segment(5);
        $data = $this->m_doch->get_akt_den($id);
        foreach ($data as $r){
            $den = $r->DEN;
            $svia = $r->SVIATOK;
        }
        $uzi = $this->m_doch->get_uziv_data($id_uziv);
        foreach ($uzi as $u){
            $typ = $u->ARCINTCIS;
            $id_miesto_uziv = $u->id_miesto;
        }
        $uzi_den = $this->m_doch->get_id_den($d, $id_uziv);
        $hod = 0;
        $dn = 0;
        $i = 0;
        // print_r( $data );
        // $a = $data->num_rows();
        // print_r( $a );
        $od = '';
        $do = '';
        $pozn = '';
        $cinnost = '';
        $h = 0;
        $mie = 0;
        foreach ($uzi_den as $r){
            if(($r->id_miesto < 4) || ($r->id_miesto == 13) || ($r->id_miesto == 15)){ //práca, školenie, home-office
                if($id_uziv == 5){
                    if($r->id_miesto == 1){
                        $hod = $hod + $r->HODINY;
                    } else {
                        $dn = $dn + $r->HODINY;
                    }
                } else {
                    $hod = $hod + $r->HODINY;
                }
            }
            if($r->id_miesto < 4){
                if($i == 0){
                    if($id_miesto_uziv != $r->id_miesto){$mie = $r->id_miesto;}
                } else {
                    if($id_miesto_uziv != $r->id_miesto){
                        if($mie != $r->id_miesto){$mie = 4;}
                    }
                }
                if($r->id_miesto == 1){$cinnost = 'z.had';}
                if($r->id_miesto == 2){$cinnost = 'da.ZV';}
                if($r->id_miesto == 3){$cinnost = 'da.DN';}
            } else {
                $cin = $this->m_doch->get_cin_data($r->id_miesto);
                foreach ($cin as $c){
                    $cinnost = $c->POPIS;
                }
            }
            
            if($i == 0){
                $od = $r->OD;
                $pozn = $cinnost;
                $h = round($r->HODINY, 2);
            } else {
                if($i == 1){ $pozn = $pozn . ' ' . number_format($h,2,'.',''); };
                $pozn = $pozn . ' + ' . $cinnost . ' ' . round($r->HODINY, 2);
            }
            
            $do = $r->DO;
            $i++;
        }
        $ob = 0;
        if($hod >= 4.5){$ob = 1;};
        //if($hod > 6){$hod = $hod - 0.5;};
        $nadcas = 0;
        if($typ == 8){
            if(($svia == 1) || ($den == 'So') || ($den == 'Ne')){
                $nadcas = $hod;
                if($svia == 0){$ob = 1;}
            } else {
                if(($hod != 8.5) && ($hod != 0)){$nadcas = $hod - 8.5;};
            }
        }
        if($typ == 4){
            $ob = 0;
            if(($svia == 1) || ($den == 'So') || ($den == 'Ne')){
                $nadcas = $hod;
            } else {
                if(($hod != 4) && ($hod != 0)){$nadcas = $hod - 4;};
            }
        }
        $den = array(
            'PRICHOD' => $od,
            'ODCHOD' => $do,
            'POZN' => $pozn,
            'OBED' => $ob,
            'HODINY' => $hod,
            'NADCAS' => $nadcas,
            'HODINY_DN' => $dn,
            'MIESTO' => $mie
        ); $this->m_doch->upd_den_1_prac($den, $id);
        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }
    function del_hod(){
        $id = $this->uri->segment(3);
        $this->m_doch->del_hod($id);
        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }
    function kontroluj_hod(){
        $d = $this->uri->segment(3);
        if(strlen($d)==10){
            $_SESSION['den'] = strtotime($d);
        };
        $dni = cal_days_in_month(CAL_JULIAN,substr($d,3,2),substr($d,6,4));
        $data = $this->m_doch->get_all_job_hours($d);
        foreach ($data as $q){
            $id = $q->id;
            $datum = $q->DATUM;
            $den_t = $q->DEN;
            $svia = $q->SVIATOK;
            $id_uziv = $q->id_uziv;
            $typ = '';
            $uzi = $this->m_doch->get_uziv_data($id_uziv);
            foreach ($uzi as $u){
                $typ = $u->ARCINTCIS;
                $id_miesto_uziv = $u->id_miesto;
            }
            $uzi_den = $this->m_doch->get_id_den($datum, $id_uziv);
            $hod = 0;
            $dn = 0;
            $i = 0;
            $od = '';
            $do = '';
            $pozn = '';
            $cinnost = '';
            $mie = 0;
            foreach ($uzi_den as $r){
                if(($r->id_miesto < 4) || ($r->id_miesto == 13) || ($r->id_miesto == 15)){ //práca, školenie, home-office
                    if($id_uziv == 5){
                        if($r->id_miesto == 1){
                            $hod = $hod + $r->HODINY;
                        } else {
                            $dn = $dn + $r->HODINY;
                        }
                    } else {
                        $hod = $hod + $r->HODINY;
                    }
                }
                if($r->id_miesto < 4){
                    if($i == 0){
                        if($id_miesto_uziv != $r->id_miesto){$mie = $r->id_miesto;}
                    } else {
                        if($id_miesto_uziv != $r->id_miesto){
                            if($mie != $r->id_miesto){$mie = 4;}
                        }
                    }
                    if($r->id_miesto == 1){$cinnost = 'z.had';}
                    if($r->id_miesto == 2){$cinnost = 'da.ZV';}
                    if($r->id_miesto == 3){$cinnost = 'da.DN';}
                } else {
                    $cin = $this->m_doch->get_cin_data($r->id_miesto);
                    foreach ($cin as $c){
                        $cinnost = $c->POPIS;
                    }
                }
                
                if($i == 0){
                    $od = $r->OD;
                    $pozn = $cinnost;
                    $h = round($r->HODINY, 2);
                } else {
                    if($i == 1){ $pozn = $pozn . ' ' . number_format($h,2,'.',''); };
                    $pozn = $pozn . ' + ' . $cinnost . ' ' . round($r->HODINY, 2);
                }
                
                $do = $r->DO;
                $i++;
            }
            $ob = 0;
            if($hod >= 4.5){$ob = 1;};
            //if($hod > 6){$hod = $hod - 0.5;};
            $nadcas = 0;
            if($typ == 8){
                if(($svia == 1) || ($den_t == 'So') || ($den_t == 'Ne')){
                    $nadcas = $hod;
                    if($svia == 0){$ob = 1;}
                } else {
                    if(($hod != 8.5) && ($hod != 0)){$nadcas = $hod - 8.5;};
                }    
            }
            if($typ == 4){
                if(($svia == 1) || ($den_t == 'So') || ($den_t == 'Ne')){
                    $nadcas = $hod;
                    if($svia == 0){$ob = 1;}
                } else {
                    if(($hod != 4.5) && ($hod != 0)){$nadcas = $hod - 4.5;};
                }
            }
            $den = array(
                'PRICHOD' => $od,
                'ODCHOD' => $do,
                'POZN' => $pozn,
                'OBED' => $ob,
                'HODINY' => $hod,
                'NADCAS' => $nadcas,
                'HODINY_DN' => $dn,
                'MIESTO' => $mie
            ); $this->m_doch->upd_den_1_prac($den, $id);
        }
        $array = array('success' => '<div class="alert alert-success">Thanks</div>');
        echo json_encode($array);
    }



    
    function list(){
        $_SESSION['zak_zoz'] = $this->m_zakazky->get_zak_zoz();
        $_SESSION['casti'] = $this->m_zakazky->get_casti();
        $_SESSION['pract'] = $this->m_zakazky->get_pracT();
        $_SESSION['pracm'] = $this->m_zakazky->get_pracM();
        $prio = $this->session->userdata('prio');
        if($prio>5 || $prio==2){
            if($prio==2){
                $data['team'] = $this->m_uziv->get_prirad();
            }else{
                $data['team'] = $this->m_uziv->get_aktu();
            }
            $this->load->view("doch/form_dochadzka", $data);
        } else {
            $this->load->view("doch/form_dochadzka_1");
        }
    }
    function lista(){
        $z = $this->uri->segment(3);
        if(strlen($z)==10){$_SESSION['den'] = strtotime($z);};
        $_SESSION['zak_zoz'] = $this->m_zakazky->get_zak_zoz();
        $_SESSION['casti'] = $this->m_zakazky->get_casti();
        $_SESSION['pract'] = $this->m_zakazky->get_pracT();
        $_SESSION['pracm'] = $this->m_zakazky->get_pracM();
        if($prio==2){
            $data = $this->m_uziv->get_prirad();
        }else{
            $data = $this->m_uziv->get_aktu();
        } echo json_encode($data);
    }
    function doch(){
        $z = $this->uri->segment(3);
        if(strlen($z)==10){$_SESSION['den'] = strtotime($z);};
        $data["doch"] = $this->m_doch->get_doch();
        $this->load->view("doch/form_dochadzka", $data);
    }
    function docha(){
        $z = $this->uri->segment(3);
        if(strlen($z)==10){$_SESSION['den'] = strtotime($z);};
        $data = $this->m_doch->get_doch();
        //print_r($_REQUEST);
        echo json_encode($data);
    }
    function mes_doch(){
        $d = $this->uri->segment(3);
        $p = $this->uri->segment(4);
        $c = $this->uri->segment(5);
        if(strlen($d)==10){$_SESSION['den'] = strtotime($d);};
        $_SESSION['zak_zoz'] = $this->m_zakazky->get_zak_zoz();
        $_SESSION['zak1_zoz'] = $this->m_zakazky->get_fil_zak_zoz();
        $_SESSION['casti'] = $this->m_zakazky->get_casti();
        $_SESSION['pract'] = $this->m_zakazky->get_pracT();
        $_SESSION['pracm'] = $this->m_zakazky->get_pracM();
        $prio = $this->session->userdata('prio');
        if($prio>5 || $prio==2){
            $z = $this->uri->segment(4);
            $data["doch"] = $this->m_doch->get_mes($z,$p,$c,'1');
            $data['cinnosti'] = $this->m_doch->get_mes_cinn();
            $data['zakazky'] = $this->m_doch->get_mes_zaka();
            $data['lenzaka'] = $this->m_doch->get_mes_zakl();
            $data['zak_prac'] = $this->m_doch->get_mes_prac();
            $data['zak_cast'] = $this->m_doch->get_mes_cast();
            $this->load->view("doch/form_doch_mes", $data);
        } else {
            $data["doch"] = $this->m_doch->get_mes_1();
            $this->load->view("doch/form_doch_mes_1", $data);
        }
    }
    function zak_prac(){
        $data = $this->m_doch->get_mes_prac();
        echo json_encode($data);
    }
    function zak_cast(){
        $data = $this->m_doch->get_mes_cast();
        echo json_encode($data);
    }
    function zak_cinn(){
        $data = $this->m_doch->get_mes_cinn();
        echo json_encode($data);
    }
    function zak_zaka(){
        $data = $this->m_doch->get_mes_zaka();
        echo json_encode($data);
    }
    function zak_zakl(){
        $data = $this->m_doch->get_mes_zakl();
        echo json_encode($data);
    }
    function get_skup(){
        $data = $this->m_uziv->get_skup();
        echo json_encode($data);
    }
    function get_uziv_skup(){
        $data = $this->m_uziv->get_uziv_skup();
        echo json_encode($data);
    }
    function prehlad(){
        $s = $this->m_uziv->get_uziv_skup();
        $this->m_doch->prehlad_ini();
        $this->load->view("doch/form_prehlad");
    }
    function jprehlad(){
        $sk = urldecode($this->uri->segment(3));
        $po = urldecode($this->uri->segment(4));
        $d = $this->uri->segment(5);
        $chk = $this->uri->segment(6);
        if($po==null){$po='.';}
        if($chk==null){
            $po='.';
            $d = $this->uri->segment(4);
            $chk = $this->uri->segment(5);
        }
        if(strlen($d)!=7){$d = date('m.Y');};
        $x = 1;
        $z = $this->m_doch->get_skup_zak_zoznam($sk, $po, $d, $x);
        //echo"<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>.$sk";
        //print_r($z); 
        $_SESSION['z'] = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''];
        if($sk!=null){
            if(count($z)>1){
                //echo $p->SKUPINA;print_r($z);echo"<br>";
                $u = $this->m_doch->get_skup_uzi_zoznam($sk, $po, $d);
                //echo $p->SKUPINA;print_r($u);echo"<br>";
                foreach ($u as $q){
                    //echo $q->MENO;echo"<br>";
                    $h = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]; $i = 0;
                    foreach ($z as $r){
                        $hod = $this->m_doch->get_hod_uzi_zak($q->MENO, $d, $r->CISZAK);
                        $h[$i] = 0;
                        if($hod!=null){$h[$i] = $hod;}
                        $_SESSION['z'][$i] = $r->CISZAK;
                        $i++;
                    }
                    $sumzak = $h[0]+$h[1]+$h[2]+$h[3]+$h[4]+$h[5]+$h[6]+$h[7]+$h[8]+$h[9]+$h[10]+$h[11]+$h[12]+$h[13]+$h[14]+$h[15]+$h[16]+$h[17]+$h[18]+$h[19]+$h[20]+$h[21]+$h[22]+$h[23]+$h[24];
                    $hod = $this->m_doch->get_hod_uzi_rezia($q->MENO, $d);
                    $h[$i] = 0; if($hod!=null){if($hod!=0){$h[$i] = $hod;$_SESSION['z'][$i] = 'réžia';$i++;}}
                    $hod = $this->m_doch->get_hod_uzi_doprava($q->MENO, $d);
                    $h[$i] = 0; if($hod!=null){if($hod!=0){$h[$i] = $hod;$_SESSION['z'][$i] = 'doprava';$i++;}}
                    $hod = $this->m_doch->get_hod_uzi_rekon($q->MENO, $d);
                    $h[$i] = 0; if($hod!=null){if($hod!=0){$h[$i] = $hod;$_SESSION['z'][$i] = 'rekon';$i++;}}
                    $hod = $this->m_doch->get_hod_uzi_udrzba($q->MENO, $d);
                    $h[$i] = 0; if($hod!=null){if($hod!=0){$h[$i] = $hod;$_SESSION['z'][$i] = 'údržba';}}
                    if(($chk=='zak' && $sumzak>0) || ($chk=='all')){
                        $data = array(
                            'MENO' => $q->MENO,
                            'Z1' => $h[0],
                            'Z2' => $h[1],
                            'Z3' => $h[2],
                            'Z4' => $h[3],
                            'Z5' => $h[4],
                            'Z6' => $h[5],
                            'Z7' => $h[6],
                            'Z8' => $h[7],
                            'Z9' => $h[8],
                            'Z10' => $h[9],
                            'Z11' => $h[10],
                            'Z12' => $h[11],
                            'Z13' => $h[12],
                            'Z14' => $h[13],
                            'Z15' => $h[14],
                            'Z16' => $h[15],
                            'Z17' => $h[16],
                            'Z18' => $h[17],
                            'Z19' => $h[18],
                            'Z20' => $h[19],
                            'Z21' => $h[20],
                            'Z22' => $h[21],
                            'Z23' => $h[22],
                            'Z24' => $h[23],
                            'Z25' => $h[24],
                            'SPOLU' => $h[0]+$h[1]+$h[2]+$h[3]+$h[4]+$h[5]+$h[6]+$h[7]+$h[8]+$h[9]+$h[10]+$h[11]+$h[12]+$h[13]+$h[14]+$h[15]+$h[16]+$h[17]+$h[18]+$h[19]+$h[20]+$h[21]+$h[22]+$h[23]+$h[24]
                        ); $this->m_doch->add_prehlad($data);
                    }
                }
            }
        }
        $data = $this->m_doch->get_prehlad();
        echo json_encode($data);
    }
    function jb_rozpis(){
        $this->m_doch->prehlad_ini();
        $_SESSION['zak_zoz'] = $this->m_zakazky->get_zak_zoz_ps();
        $this->load->view("doch/form_mes_den_jb");
    }
    function jbrozpis(){
        $d = urldecode($this->uri->segment(3));
        $cz = urldecode($this->uri->segment(4));
        //echo "<br>"."<br>"."<br>"."<br>"."<br>";
        if($cz==null){}else{
            if(strlen($d)!=7){$d = date('m.Y');};
            $x = 1;
            $_SESSION['z'] = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''];
            $u = $this->m_doch->get_zak_uzi_zoznam($cz, $d);
            //print_r( $u );
            foreach ($u as $q){
                $h = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0];
                $i = 0;
                $prof = $this->m_doch->get_uzi_prof($q->MENO);
                //print_r( urldecode($q->MENO) );
                while ($i < 31){
                    $den = strval($i + 1);
                    if(strlen($den)!=2){$den = '0'.$den;}
                    $den = $den.'.'.$d;
                    // print_r( $q->MENO . '  ' . $den ); echo"<br>";
                    $hod = $this->m_doch->get_hod_den_uzi_zak(urldecode($q->MENO), $den, $cz);
                    $h[$i] = 0;
                    if($hod!=null){$h[$i] = $hod;}
                    $i++;
                }
                $summes = $h[0]+$h[1]+$h[2]+$h[3]+$h[4]+$h[5]+$h[6]+$h[7]+$h[8]+$h[9]+$h[10]+$h[11]+$h[12]+$h[13]+$h[14]+$h[15]+$h[16]+$h[17]+$h[18]+$h[19]+$h[20]+$h[21]+$h[22]+$h[23]+$h[24]+$h[25]+$h[26]+$h[27]+$h[28]+$h[29]+$h[30];
                $data = array(
                    'MENO' => urldecode($q->MENO),
                    'Z1' => $h[0],
                    'Z2' => $h[1],
                    'Z3' => $h[2],
                    'Z4' => $h[3],
                    'Z5' => $h[4],
                    'Z6' => $h[5],
                    'Z7' => $h[6],
                    'Z8' => $h[7],
                    'Z9' => $h[8],
                    'Z10' => $h[9],
                    'Z11' => $h[10],
                    'Z12' => $h[11],
                    'Z13' => $h[12],
                    'Z14' => $h[13],
                    'Z15' => $h[14],
                    'Z16' => $h[15],
                    'Z17' => $h[16],
                    'Z18' => $h[17],
                    'Z19' => $h[18],
                    'Z20' => $h[19],
                    'Z21' => $h[20],
                    'Z22' => $h[21],
                    'Z23' => $h[22],
                    'Z24' => $h[23],
                    'Z25' => $h[24],
                    'Z26' => $h[25],
                    'Z27' => $h[26],
                    'Z28' => $h[27],
                    'Z29' => $h[28],
                    'Z30' => $h[29],
                    'Z31' => $h[30],
                    'SPOLU' => $summes,
                    'PROFESIA' => $prof
                ); $this->m_doch->add_prehlad($data);
            }
        }
        $data = $this->m_doch->get_prehlad();
        echo json_encode($data);
    }
    function hr_rozpis(){
        $this->m_doch->prehlad_ini();
        $this->load->view("doch/form_mes_den_hr");
    }
    function get_uziv_skup_hr(){
        $data = $this->m_uziv->get_uziv_skup_hr();
        $this->m_doch->prehlad_ini();
        echo json_encode($data);
    }
    function hrrozpis(){
        $this->m_doch->prehlad_ini();
        $d = urldecode($this->uri->segment(3));
        $sk = urldecode($this->uri->segment(4));
        $po = urldecode($this->uri->segment(5));
        //echo "<br>"."<br>"."<br>"."<br>"."<br>";
        $u = $this->m_doch->get_skup_uzi_zoznam($sk, $po, $d);
        // print_r($sk.'  '.$po);echo"<br>";
        //print_r($u);echo"<br>";
        if(strlen($d)!=7){$d = date('m.Y');};
        $_SESSION['z'] = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''];
        if($sk==null){
            $this->m_doch->prehlad_ini();
        }else{
            foreach ($u as $q){
                //print_r( $u );
                $h = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0];
                $i = 0;
                while ($i < 31){
                    $den = strval($i + 1);
                    if(strlen($den)!=2){$den = '0'.$den;}
                    $den = $den.'.'.$d;
                    //print_r( $q->MENO . '  ' . $den ); echo"<br>";
                    $hod = $this->m_doch->get_sum_hod_den_uzi(urldecode($q->MENO), $den);
                    $h[$i] = 0;
                    if($hod!=null){$h[$i] = $hod;}
                    $i++;
                }
                $summes = $h[0]+$h[1]+$h[2]+$h[3]+$h[4]+$h[5]+$h[6]+$h[7]+$h[8]+$h[9]+$h[10]+$h[11]+$h[12]+$h[13]+$h[14]+$h[15]+$h[16]+$h[17]+$h[18]+$h[19]+$h[20]+$h[21]+$h[22]+$h[23]+$h[24]+$h[25]+$h[26]+$h[27]+$h[28]+$h[29]+$h[30];
                $data = array(
                    'MENO' => urldecode($q->MENO),
                    'Z1' => $h[0],
                    'Z2' => $h[1],
                    'Z3' => $h[2],
                    'Z4' => $h[3],
                    'Z5' => $h[4],
                    'Z6' => $h[5],
                    'Z7' => $h[6],
                    'Z8' => $h[7],
                    'Z9' => $h[8],
                    'Z10' => $h[9],
                    'Z11' => $h[10],
                    'Z12' => $h[11],
                    'Z13' => $h[12],
                    'Z14' => $h[13],
                    'Z15' => $h[14],
                    'Z16' => $h[15],
                    'Z17' => $h[16],
                    'Z18' => $h[17],
                    'Z19' => $h[18],
                    'Z20' => $h[19],
                    'Z21' => $h[20],
                    'Z22' => $h[21],
                    'Z23' => $h[22],
                    'Z24' => $h[23],
                    'Z25' => $h[24],
                    'Z26' => $h[25],
                    'Z27' => $h[26],
                    'Z28' => $h[27],
                    'Z29' => $h[28],
                    'Z30' => $h[29],
                    'Z31' => $h[30],
                    'SPOLU' => $summes
                ); $this->m_doch->add_prehlad($data);
            }
        }
        $data = $this->m_doch->get_prehlad();
        echo json_encode($data);
    }
    function get_skup_zak_zoznam() {
        $data = $_SESSION['z'];
        echo json_encode($data);
    }
    function mesa(){
        $d = $this->uri->segment(3);
        if(strlen($d)==10){$_SESSION['den'] = strtotime($d);};
        $this->load->view("doch/form_doch_mesa");
    }
    function mes_docha(){
        $d = $this->uri->segment(3);
        $z = $this->uri->segment(4);
        $p = $this->uri->segment(5);
        $c = $this->uri->segment(6);
        $m = $this->uri->segment(7);
        if($m==null){$m='1';}
        if(strlen($d)==10){$_SESSION['den'] = strtotime($d);};
        $data = $this->m_doch->get_mes($z,$p,$c,$m);
        echo json_encode($data);
    }
    function mes_docha_1(){
        $d = $this->uri->segment(3);
        if(strlen($d)==10){$_SESSION['den'] = strtotime($d);};
        $data = $this->m_doch->get_mes_1();
        echo json_encode($data);
    }
    function fin(){
        $d = $this->uri->segment(3);
        if($_SESSION['den'] != strtotime($d)){
            $_SESSION['den'] = strtotime($d);};
        $z = $this->uri->segment(4);
        $data = $this->m_doch->get_fin($d,$z);
        echo json_encode($data);
    }
    function prac(){
        $d = $this->uri->segment(3);
        if($_SESSION['den'] != strtotime($d)){
            $_SESSION['den'] = strtotime($d);};
        $z = $this->uri->segment(4);
        $data = $this->m_doch->get_prac($d,$z);
        echo json_encode($data);
    }
    function pracT(){
        $z = $this->uri->segment(3);
        $data = $this->m_doch->get_pracT($z);
        echo json_encode($data);
    }
    function delprac(){
        $z = $this->uri->segment(3);
        $this->m_doch->del_prac($z);

        $d = $this->uri->segment(4);
        if($_SESSION['den'] != strtotime($d)){
            $_SESSION['den'] = strtotime($d);};
        $z = $this->uri->segment(5);
        $data = $this->m_doch->get_prac($d,$z);
        echo json_encode($data);
    }
    function addprac(){
        $h = $this->input->post('hodiny');
        if(strpos($h,',')){$h=str_replace(',','.',$h);}
        $n = $this->input->post('nadcas');
        if(strpos($n,',')){$n=str_replace(',','.',$n);}
        $z='';
        if($this->input->post('zakazka')!=0){
            $z=$this->input->post('zakazka');
        }
        if($this->input->post('zt')!=null){
            $z=$this->input->post('zt');
        }
        $ca = $this->input->post('cast');
        $c = $this->input->post('cast_popis');
        if($z != ''){
            $c = $this->m_zakazky->get_cast_popis($ca);
        }else{
            $ca = $this->m_zakazky->get_cast_cinnost($this->input->post('skratka'));
        }
        $sk = $this->m_uziv->get_skup_prac($this->uri->segment(3));
        $po = $this->m_uziv->get_poz_prac($this->uri->segment(3));
        $data = array(
            'KOD' => $this->uri->segment(3),
            'DATUM' => $this->uri->segment(4),
            'TRVANIE' => $h,
            'POZN' => $this->input->post('pozn'),
            'KOD_ZADAL' => $this->uri->segment(5),
            'CISZAK' => $z,
            'CAST' => $ca,
            'NADCAS'  => $n,
            'SKRATKA' => $this->input->post('skratka'),
            'AKYDEN' => $this->input->post('akyden'),
            'HODMIN' => '',
            'MENO' => $this->input->post('meno'),
            'CAST_POPIS' => $c,
            'ARCINTCIS' => '',
            'PRICHOD' => '',
            'ODCHOD' => '',
            'OS_CISLO' => 0,
            'IODCHOD' => '',
            'SKUPINA' => $sk,
            'POZICIA' => $po
        ); $this->m_doch->add_prac($data);

        // echo("</br>"."</br>"."</br>"."</br>"."</br>");
        // print_r($z);

        if($z != ''){
            $czt = $z;
            $ciszak = $this->m_zakazky->get_cz_frczt($czt);
            $id = $this->m_zakazky->get_idzak($ciszak);
            $sumprac = $this->m_zakazky->prace_zak1($czt);
            $s1=0; $s2=0; $s3=0; $s4=0; $s5=0; $s6=0; $s7=0; $s8=0; $s9=0; $s10=0; $s12=0;
            // echo("</br>"."</br>"."</br>"."</br>"."</br>");
            // print_r($sumprac);
            foreach($sumprac as $s){
                if(substr($s->CAST,0,2)=='01'){$s1=$s1+$s->TRVANIE;}
                if($s->CAST=='02'){$s2=$s2+$s->TRVANIE;}
                if($s->CAST=='03'){$s3=$s3+$s->TRVANIE;}
                if($s->CAST=='04'){$s4=$s4+$s->TRVANIE;}
                if($s->CAST=='05'){$s5=$s5+$s->TRVANIE;}
                if($s->CAST=='06'){$s6=$s6+$s->TRVANIE;}
                if($s->CAST=='07'){$s7=$s7+$s->TRVANIE;}
                if($s->CAST=='08'){$s8=$s8+$s->TRVANIE;}
                if($s->CAST=='09'){$s9=$s9+$s->TRVANIE;}
                if($s->CAST=='10'){$s10=$s10+$s->TRVANIE;}
                if($s->CAST=='12'){$s12=$s12+$s->TRVANIE;}
            }
            $data = array(
                'DOKU_CAS_S' => $s1,
                'MTZ_CAS_SK' => $s2,
                'VYR_CAS_SK' => $s3,
                'KOOP_CAS_S' => $s4,
                'VLUC_CAS_S' => $s5,
                'OTK_CAS_SK' => $s6,
                'DOPR_CAS_S' => $s7,
                'OBAL_CAS_S' => $s8,
                'MONT_CAS_S' => $s9,
                'REZIA_CAS_' => $s10,
                'NAVIAC_CA1' => $s12
            );  $this->m_zakazky->upd_evizakrekap($data,$ciszak);

            $sumo = [0,0,0,0,0,0,0,0,0,0,0,0,0]; // $ca = $this->m_zakazky->get_casti();
            $sumv = 0;
            //$ciszak = $r->CISZAK;
            $sumo[0] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'01');
            $sumo[1] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'02');
            $sumo[2] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'03');
            $sumo[3] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'04');
            $sumo[4] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'05');
            $sumo[5] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'06');
            $sumo[6] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'07');
            $sumo[7] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'08');
            $sumo[8] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'09');
            $sumo[9] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'10');
            $sumo[10] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'12');
            $sumo[11] = $this->m_zakazky->get_sum_zak_naviac('wobjed',$ciszak);

            $sumv = $this->m_zakazky->get_sum_zak_cast('wvydajky',$ciszak,'02');
            $zrek_id = $this->m_zakazky->get_idzrek($ciszak);
            $rek = $this->m_zakazky->get_evizakrekap1($ciszak);

            // print_r("<br>"."<br>"."<br>"."<br>"."<br>"."<br>".count($rek));
            // print_r($rek);
            //if(count($rek)>0){
                foreach ($rek as $re) { //echo $ciszak . date("H:i:s");
                    $CE_OB_KO =  $sumo[0] + $sumo[1] + $sumo[2] + $sumo[3] + $sumo[4] + $sumo[5] + $sumo[6] + $sumo[7] + $sumo[8] + $sumo[9] + $sumo[10] + $sumo[11];
                    $CE_SK_KO =  $sumv + $sumo[0] + $sumo[2] + $sumo[3] + $sumo[4] + $sumo[5] + $sumo[6] + $sumo[7] + $sumo[8] + $sumo[9] + $sumo[10] + $sumo[11];
                    $data = array(
                        'DOKU_SUM_S' => $re->DOKU_CAS_SUM_SKUT + $sumo[0],
                        'MTZ_SUM_SK' => $re->MTZ_CAS_SUM_SKUT + $sumo[1],
                        'VYR_SUM_SK' => $re->VYR_CAS_SUM_SKUT + $sumo[2],
                        'KOOP_SUM_S' => $re->KOOP_CAS_SUM_SKUT + $sumo[3],
                        'VLUC_SUM_S' => $re->VLUC_CAS_SUM_SKUT + $sumo[4],
                        'OTK_SUM_SK' => $re->OTK_CAS_SUM_SKUT + $sumo[5],
                        'DOPR_SUM_S' => $re->DOPR_CAS_SUM_SKUT + $sumo[6],
                        'OBAL_SUM_S' => $re->OBAL_CAS_SUM_SKUT + $sumo[7],
                        'MONT_SUM_S' => $re->MONT_CAS_SUM_SKUT + $sumo[8],
                        'REZIA_SUM_' => $re->REZIA_CAS_SUM_SKUT + $sumo[9],
                        'DOKU_SUM_O' => $sumo[0],
                        'MTZ_SUM_OB' => $sumo[1],
                        'VYR_SUM_OB' => $sumo[2],
                        'KOOP_SUM_O' => $sumo[3],
                        'VLUC_SUM_O' => $sumo[4],
                        'OTK_SUM_OB' => $sumo[5],
                        'DOPR_SUM_O' => $sumo[6],
                        'OBAL_SUM_O' => $sumo[7],
                        'MONT_SUM_O' => $sumo[8],
                        'REZIA_SUM1' => $sumo[9],
                        'NAVIAC_SU2' => $sumo[10] + $sumo[11],
                        'CHYBA_SUM_' => 0,
                        'CELKOM_OBJ' => $CE_OB_KO,
                        'DOKU_SUM_V' => $sumo[0],
                        'MTZ_SUM_VZ' => $sumv,
                        'VYR_SUM_VZ' => $sumo[2],
                        'KOOP_SUM_V' => $sumo[3],
                        'VLUC_SUM_V' => $sumo[4],
                        'OTK_SUM_VZ' => $sumo[5],
                        'DOPR_SUM_V' => $sumo[6],
                        'OBAL_SUM_V' => $sumo[7],
                        'MONT_SUM_V' => $sumo[8],
                        'REZIA_SUM2' => $sumo[9],
                        'NAVIAC_SU3' => $sumo[10] + $sumo[11],
                        'CELKOM_VZP' => $CE_SK_KO,
                        'DOKU_SUM_1' => $re->DOKU_CAS_SUM_SKUT + $sumo[0],
                        'MTZ_SUM_S1' => $re->MTZ_CAS_SUM_SKUT + $sumv,
                        'VYR_SUM_S1' => $re->VYR_CAS_SUM_SKUT + $sumo[2],
                        'KOOP_SUM_1' => $re->KOOP_CAS_SUM_SKUT + $sumo[3],
                        'VLUC_SUM_1' => $re->VLUC_CAS_SUM_SKUT + $sumo[4],
                        'OTK_SUM_S1' => $re->OTK_CAS_SUM_SKUT + $sumo[5],
                        'DOPR_SUM_1' => $re->DOPR_CAS_SUM_SKUT + $sumo[6],
                        'OBAL_SUM_1' => $re->OBAL_CAS_SUM_SKUT + $sumo[7],
                        'MONT_SUM_1' => $re->MONT_CAS_SUM_SKUT + $sumo[8],
                        'REZIA_SUM3' => $re->REZIA_CAS_SUM_SKUT + $sumo[9]
                    ); $this->m_zakazky->upd_evizakrekap($data,$ciszak);
                }
                $a = 2;
                $kal = $re->CELKOM_KONTROLA - $re->ZISK;
                $obj = $re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO + $re->REZIA_UCT;
                $per = 0;
                if($kal>0){$per = (int)(($obj * 100) / $kal);}
                //print_r($per); echo"<br>";
                $data = array(
                    'CELKOM_OBJ' => number_format($CE_OB_KO,0,", "," "),
                    'CELKOM_CAS' => number_format($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO,0,", "," "),
                    //'REZIA_UCT' => $re->REZIA_UCT,
                    'CELKOM_SKU' => number_format($CE_SK_KO,0,", "," "),
                    'CELKOM_KON' => number_format($re->CELKOM_KONTROLA,0,", "," "),

                    'CELKOM_OB1' => number_format($CE_OB_KO,0,", "," "),
                    'CELKOM_CA1' => number_format($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO + $re->REZIA_UCT,0,", "," "),
                    'CELKOM_CA2' => number_format($re->CELKOM_KONTROLA + $re->REZIA_UCT,0,", "," "),
                    'ROZDIEL_VZ' => number_format($re->CELKOM_KONTROLA - 
                                                ($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_SK_KO + $re->REZIA_UCT),0,", "," "),
                    'REZIA_UCT_' => number_format($re->REZIA_UCT,0,", "," "),
                    'CELKOM_SK1' => number_format($CE_SK_KO,0,", "," "),
                    'CELKOM_KO1' => number_format($re->CELKOM_KONTROLA,0,", "," "),
                    'NAKLADY_RO' => number_format($re->CELKOM_KONTROLA - 
                                                ($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO + $re->REZIA_UCT),0,", "," "),
                    'PERC' => $per . '%',
                    'ZISK' => $re->ZISK
                );
                $this->m_zakazky->upd_evizak($data,$id);
            //}
        }
    }
    function updprac(){
        $h = $this->input->post('hodiny');
        if(strpos($h,',')){$h=str_replace(',','.',$h);}
        $n = $this->input->post('nadcas');
        if(strpos($n,',')){$n=str_replace(',','.',$n);}
        $z='';
        if($this->input->post('zakazka')!=0){
            $z=$this->input->post('zakazka');
        }
        if($this->input->post('zt')!=null){
            $z=$this->input->post('zt');
        }
        $ca = $this->input->post('cast');
        $c = $this->input->post('cast_popis');
        if($z != ''){
            $c = $this->m_zakazky->get_cast_popis($ca);
        }else{
            $ca = $this->m_zakazky->get_cast_cinnost($this->input->post('skratka'));
        }
        $data = array(
            'KOD' => $this->uri->segment(3),
            'DATUM' => $this->uri->segment(4),
            'TRVANIE' => $h,
            'POZN' => $this->input->post('pozn'),
            'KOD_ZADAL' => $this->uri->segment(5),
            'CISZAK' => $z,
            'CAST' => $ca,
            'NADCAS'  => $n,
            'SKRATKA' => $this->input->post('skratka'),
            'AKYDEN' => $this->input->post('akyden'),
            'HODMIN' => '',
            'MENO' => $this->input->post('meno'),
            'CAST_POPIS' => $c,
            'ARCINTCIS' => '',
            'PRICHOD' => '',
            'ODCHOD' => '',
            'OS_CISLO' => 0,
            'IODCHOD' => ''
        ); $i = $this->uri->segment(6);
        $this->m_doch->upd_prac($data,$i);

        // echo("</br>"."</br>"."</br>"."</br>"."</br>");
        // print_r($z);

        if($z != ''){
            $czt = $z;
            $ciszak = $this->m_zakazky->get_cz_frczt($czt);
            $id = $this->m_zakazky->get_idzak($ciszak);
            $pauzak = $this->m_zakazky->get_pau_czt($czt);
            $pau = 0; $x = 0;
            foreach($pauzak as $pz){
                $pau = $pz->DOKU_PAU + $pz->MTZ_PAU + $pz->VYR_PAU + $pz->KOOP_PAU + $pz->VLUC_PAU + $pz->OTK_PAU + $pz->DOPR_PAU + $pz->OBAL_PAU + $pz->MONT_PAU;
                if($pz->DOKU_PAU>0){$x++;} if($pz->MTZ_PAU>0){$x++;} if($pz->VYR_PAU>0){$x++;} if($pz->KOOP_PAU>0){$x++;} if($pz->VLUC_PAU>0){$x++;}
                if($pz->OTK_PAU>0){$x++;} if($pz->DOPR_PAU>0){$x++;} if($pz->OBAL_PAU>0){$x++;} if($pz->MONT_PAU>0){$x++;}
            }
            if($x>0){$pau = round($pau/$x);}else{
                $paukal = $this->m_kalkul->get_pau_czt($czt);
                foreach($paukal as $pk){
                    $pau = $pk->REZIA_PAU; $x = 0;
                    if($pk->REZIA_PAU==0){
                        $pau = $pk->DOKU_PAU + $pk->MTZ_PAU + $pk->VYR_PAU + $pk->KOOP_PAU + $pk->VLUC_PAU + $pk->OTK_PAU + $pk->DOPR_PAU + $pk->OBAL_PAU + $pk->MONT_PAU;
                        if($pk->DOKU_PAU>0){$x++;} if($pk->MTZ_PAU>0){$x++;} if($pk->VYR_PAU>0){$x++;} if($pk->KOOP_PAU>0){$x++;} if($pk->VLUC_PAU>0){$x++;}
                        if($pk->OTK_PAU>0){$x++;} if($pk->DOPR_PAU>0){$x++;} if($pk->OBAL_PAU>0){$x++;} if($pk->MONT_PAU>0){$x++;}
                    }
                    if($x>0){$pau = round($pau/$x);}
                    $data = array( 
                        'DOKU_PAU' => $pk->DOKU_PAU,
                        'MTZ_PAU' => $pk->MTZ_PAU,
                        'VYR_PAU' => $pk->VYR_PAU,
                        'KOOP_PAU' => $pk->KOOP_PAU,
                        'VLUC_PAU' => $pk->VLUC_PAU,
                        'OTK_PAU' => $pk->OTK_PAU,
                        'DOPR_PAU' => $pk->DOPR_PAU,
                        'OBAL_PAU' => $pk->OBAL_PAU,
                        'MONT_PAU' => $pk->MONT_PAU,
                        'REZIA_PAU' => $pau
                    ); 
                }
                $this->m_zakazky->upd_evizak($data,$id);
            }
            $sumprac = $this->m_zakazky->prace_zak1($czt);
            $s1=0; $s2=0; $s3=0; $s4=0; $s5=0; $s6=0; $s7=0; $s8=0; $s9=0; $s10=0; $s12=0;
            // echo("</br>"."</br>"."</br>"."</br>"."</br>");
            // print_r($sumprac);
            foreach($sumprac as $s){
                if(substr($s->CAST,0,2)=='01'){$s1=$s1+$s->TRVANIE;}
                if($s->CAST=='02'){$s2=$s2+$s->TRVANIE;}
                if($s->CAST=='03'){$s3=$s3+$s->TRVANIE;}
                if($s->CAST=='04'){$s4=$s4+$s->TRVANIE;}
                if($s->CAST=='05'){$s5=$s5+$s->TRVANIE;}
                if($s->CAST=='06'){$s6=$s6+$s->TRVANIE;}
                if($s->CAST=='07'){$s7=$s7+$s->TRVANIE;}
                if($s->CAST=='08'){$s8=$s8+$s->TRVANIE;}
                if($s->CAST=='09'){$s9=$s9+$s->TRVANIE;}
                if($s->CAST=='10'){$s10=$s10+$s->TRVANIE;}
                if($s->CAST=='12'){$s12=$s12+$s->TRVANIE;}
            }
            $data = array(
                'DOKU_CAS_S' => $s1,
                'MTZ_CAS_SK' => $s2,
                'VYR_CAS_SK' => $s3,
                'KOOP_CAS_S' => $s4,
                'VLUC_CAS_S' => $s5,
                'OTK_CAS_SK' => $s6,
                'DOPR_CAS_S' => $s7,
                'OBAL_CAS_S' => $s8,
                'MONT_CAS_S' => $s9,
                'REZIA_CAS_' => $s10,
                'NAVIAC_CA1' => $s12
            );  $this->m_zakazky->upd_evizakrekap($data,$ciszak);

            $sumo = [0,0,0,0,0,0,0,0,0,0,0,0,0]; // $ca = $this->m_zakazky->get_casti();
            $sumv = 0;
            //$ciszak = $r->CISZAK;
            $sumo[0] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'01');
            $sumo[1] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'02');
            $sumo[2] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'03');
            $sumo[3] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'04');
            $sumo[4] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'05');
            $sumo[5] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'06');
            $sumo[6] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'07');
            $sumo[7] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'08');
            $sumo[8] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'09');
            $sumo[9] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'10');
            $sumo[10] = $this->m_zakazky->get_sum_zak_cast('wobjed',$ciszak,'12');
            $sumo[11] = $this->m_zakazky->get_sum_zak_naviac('wobjed',$ciszak);

            $sumv = $this->m_zakazky->get_sum_zak_cast('wvydajky',$ciszak,'02');
            $zrek_id = $this->m_zakazky->get_idzrek($ciszak);
            $rek = $this->m_zakazky->get_evizakrekap1($ciszak);

            // print_r("<br>"."<br>"."<br>"."<br>"."<br>"."<br>".count($rek));
            // print_r($rek);
            //if(count($rek)>0){
                foreach ($rek as $re) { //echo $ciszak . date("H:i:s");
                    $CE_OB_KO =  $sumo[0] + $sumo[1] + $sumo[2] + $sumo[3] + $sumo[4] + $sumo[5] + $sumo[6] + $sumo[7] + $sumo[8] + $sumo[9] + $sumo[10] + $sumo[11];
                    $CE_SK_KO =  $sumv + $sumo[0] + $sumo[2] + $sumo[3] + $sumo[4] + $sumo[5] + $sumo[6] + $sumo[7] + $sumo[8] + $sumo[9] + $sumo[10] + $sumo[11];
                    $data = array(
                        'DOKU_SUM_S' => $re->DOKU_CAS_SUM_SKUT + $sumo[0],
                        'MTZ_SUM_SK' => $re->MTZ_CAS_SUM_SKUT + $sumo[1],
                        'VYR_SUM_SK' => $re->VYR_CAS_SUM_SKUT + $sumo[2],
                        'KOOP_SUM_S' => $re->KOOP_CAS_SUM_SKUT + $sumo[3],
                        'VLUC_SUM_S' => $re->VLUC_CAS_SUM_SKUT + $sumo[4],
                        'OTK_SUM_SK' => $re->OTK_CAS_SUM_SKUT + $sumo[5],
                        'DOPR_SUM_S' => $re->DOPR_CAS_SUM_SKUT + $sumo[6],
                        'OBAL_SUM_S' => $re->OBAL_CAS_SUM_SKUT + $sumo[7],
                        'MONT_SUM_S' => $re->MONT_CAS_SUM_SKUT + $sumo[8],
                        'REZIA_SUM_' => $re->REZIA_CAS_SUM_SKUT + $sumo[9],
                        'DOKU_SUM_O' => $sumo[0],
                        'MTZ_SUM_OB' => $sumo[1],
                        'VYR_SUM_OB' => $sumo[2],
                        'KOOP_SUM_O' => $sumo[3],
                        'VLUC_SUM_O' => $sumo[4],
                        'OTK_SUM_OB' => $sumo[5],
                        'DOPR_SUM_O' => $sumo[6],
                        'OBAL_SUM_O' => $sumo[7],
                        'MONT_SUM_O' => $sumo[8],
                        'REZIA_SUM1' => $sumo[9],
                        'NAVIAC_SU2' => $sumo[10] + $sumo[11],
                        'CHYBA_SUM_' => 0,
                        'CELKOM_OBJ' => $CE_OB_KO,
                        'DOKU_SUM_V' => $sumo[0],
                        'MTZ_SUM_VZ' => $sumv,
                        'VYR_SUM_VZ' => $sumo[2],
                        'KOOP_SUM_V' => $sumo[3],
                        'VLUC_SUM_V' => $sumo[4],
                        'OTK_SUM_VZ' => $sumo[5],
                        'DOPR_SUM_V' => $sumo[6],
                        'OBAL_SUM_V' => $sumo[7],
                        'MONT_SUM_V' => $sumo[8],
                        'REZIA_SUM2' => $sumo[9],
                        'NAVIAC_SU3' => $sumo[10] + $sumo[11],
                        'CELKOM_VZP' => $CE_SK_KO,
                        'DOKU_SUM_1' => $re->DOKU_CAS_SUM_SKUT + $sumo[0],
                        'MTZ_SUM_S1' => $re->MTZ_CAS_SUM_SKUT + $sumv,
                        'VYR_SUM_S1' => $re->VYR_CAS_SUM_SKUT + $sumo[2],
                        'KOOP_SUM_1' => $re->KOOP_CAS_SUM_SKUT + $sumo[3],
                        'VLUC_SUM_1' => $re->VLUC_CAS_SUM_SKUT + $sumo[4],
                        'OTK_SUM_S1' => $re->OTK_CAS_SUM_SKUT + $sumo[5],
                        'DOPR_SUM_1' => $re->DOPR_CAS_SUM_SKUT + $sumo[6],
                        'OBAL_SUM_1' => $re->OBAL_CAS_SUM_SKUT + $sumo[7],
                        'MONT_SUM_1' => $re->MONT_CAS_SUM_SKUT + $sumo[8],
                        'REZIA_SUM3' => $re->REZIA_CAS_SUM_SKUT + $sumo[9]
                    ); $this->m_zakazky->upd_evizakrekap($data,$ciszak);
                }
                $a = 2;
                $kal = $re->CELKOM_KONTROLA - $re->ZISK;
                $obj = $re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO + $re->REZIA_UCT;
                $per = 0;
                if($kal>0){$per = (int)(($obj * 100) / $kal);}
                //print_r($per); echo"<br>";
                $data = array(
                    'REZIA_PAU' => $pau,
                    'CELKOM_OBJ' => number_format($CE_OB_KO,0,", "," "),
                    'CELKOM_CAS' => number_format($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO,0,", "," "),
                    //'REZIA_UCT' => $re->REZIA_UCT,
                    'CELKOM_SKU' => number_format($CE_SK_KO,0,", "," "),
                    'CELKOM_KON' => number_format($re->CELKOM_KONTROLA,0,", "," "),

                    'CELKOM_OB1' => number_format($CE_OB_KO,0,", "," "),
                    'CELKOM_CA1' => number_format($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO + $re->REZIA_UCT,0,", "," "),
                    'CELKOM_CA2' => number_format($re->CELKOM_KONTROLA + $re->REZIA_UCT,0,", "," "),
                    'ROZDIEL_VZ' => number_format($re->CELKOM_KONTROLA - 
                                                ($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_SK_KO + $re->REZIA_UCT),0,", "," "),
                    'REZIA_UCT_' => number_format($re->REZIA_UCT,0,", "," "),
                    'CELKOM_SK1' => number_format($CE_SK_KO,0,", "," "),
                    'CELKOM_KO1' => number_format($re->CELKOM_KONTROLA,0,", "," "),
                    'NAKLADY_RO' => number_format($re->CELKOM_KONTROLA - 
                                                ($re->DOKU_CAS_SUM_SKUT + $re->MTZ_CAS_SUM_SKUT + $re->VYR_CAS_SUM_SKUT + $re->KOOP_CAS_SUM_SKUT + $re->VLUC_CAS_SUM_SKUT + $re->OTK_CAS_SUM_SKUT + $re->DOPR_CAS_SUM_SKUT + $re->OBAL_CAS_SUM_SKUT + $re->MONT_CAS_SUM_SKUT + $re->REZIA_CAS_SUM_SKUT + $CE_OB_KO + $re->REZIA_UCT),0,", "," "),
                    'PERC' => $per . '%',
                    'ZISK' => $re->ZISK
                );
                $this->m_zakazky->upd_evizak($data,$id);
            //}
        }
    }
}