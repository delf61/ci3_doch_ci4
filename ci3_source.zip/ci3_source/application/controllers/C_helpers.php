<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_helpers extends CI_Controller {

    function __construct() {
        parent::__construct();
        //kontrola prihlasenia
        if($this->session->userdata('status') != 'login'){
            redirect(base_url().'uvod?msg=nologin');
        }
        $this->load->helper(array( 'array', 'string', 'form' ));
    }

    function Form_helpers(){
    
        $this->load->view("Form_helpers");
    }
}
?>