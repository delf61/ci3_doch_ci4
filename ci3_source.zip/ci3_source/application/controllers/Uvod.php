<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Uvod extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('m_site');
    }
    
    public function index(){
        $this->load->view('login');
    }    
    function login(){
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $this->form_validation->set_rules('username','Username','trim|required');
        $this->form_validation->set_rules('password','Password','trim|required');
        $this->load->library(array('user_agent', 'custom_library'));
        if($this->agent->is_browser()){
            //echo "<h3>Browser name: ".$this->agent->browser().", Version: ".$this->agent->version()."</h3>";
            $agent = "Browser: ".$this->agent->browser().", ver.: " . $this->agent->version();
        }elseif ($this->agent->is_robot())
        {
            $agent = $this->agent->robot();
        }elseif($this->agent->is_mobile()){
            //echo $this->agent->mobile();
            $agent = $this->agent->mobile();
        }else{$agent = '???';}
        
        $_SESSION['bro'] = $agent;
        $_SESSION['pla'] = $this->agent->platform();
        
        $_SESSION['ipa'] = $_SERVER['REMOTE_ADDR'];
        if ( getenv("HTTP_CLIENT_IP") ) {
            $ip = getenv("HTTP_CLIENT_IP");
        } elseif ( getenv("HTTP_X_FORWARDED_FOR") ) {
            $ip = getenv("HTTP_X_FORWARDED_FOR");
            if ( strstr($ip, ',') ) {
                $tmp = explode(',', $ip);
                $ip = trim($tmp[0]);
            }
        } else {
            $ip = getenv("REMOTE_ADDR");
        }
        $_SESSION['ipb'] = $ip;
        
        if($this->form_validation->run() != false){
            if($username=='Vie Vénosová'){
                $where = array(
                    'MESO' => $username,
                    'HESO' => md5($password)
                );
            } else {
                $where = array(
                    'MESO' => $username,
                    'HESO' => md5($password)
                );
            }
            $data = $this->m_site->edit_data($where,'_uzivatelia');
            $d = $this->m_site->edit_data($where,'_uzivatelia')->row();
            $cek = $data->num_rows();
            if($cek > 0){
                $session = array(
                    'id' => $d->id,
                    //'kod' => $d->KOD,
                    'uziv' => $d->MESO,
                    'prac' => $d->MENO,
                    'prio' => $d->PRIORITA,
                    'status' => 'login'
                );
                $this->session->set_userdata($session);
                $_SESSION['den'] = strtotime(date('Y-m-d'));
                $_SESSION['file'] = '';
                $_SESSION['path_to_file'] = '';
                $_SESSION['pom'] = '';
                $_SESSION['ae'] = '';
                $_SESSION['str'] = 0;
                $_SESSION['imp'] = 0;
                $_SESSION['upd'] = 0;
                $_SESSION['zme'] = 0;
                $_SESSION['log'] = 0;
                $_SESSION['d'] = date('Y.m.d');
                $_SESSION['z'] = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''];
                $_SESSION['new'] = 1;
                $data = array(
                    'id_user' => $d->id,
                    'DATUM' => date('Y.m.d'),
                    'OD' => date("H:i:s"),
                    'DATUM_DO' => '',
                    'DO' => '',
                    'AGENT' => $agent,
                    'MENO' => $d->MENO,
                    'PLATFORM' => $_SESSION['pla'],
                    'IP' => $_SESSION['ipa'],
                    'IPB' => $_SESSION['ipb'],
                    'ARCINTCIS' => ''
                );
                $this->m_site->insert_data($data,'wuzivlog');

                // if($d->PRIORITA!=9){
                //     redirect(site_url('ulohy/list'));
                // }else{
                //     redirect(base_url().'c_site/index');
                // }
                redirect(base_url().'c_site/index');
            } else {
                $data = array(
                    'id_user' => 0,
                    'DATUM' => date('Y.m.d'),
                    'OD' => date("H:i:s"),
                    //'DATUM_DO' => '',
                    'DO' => '',
                    'AGENT' => $agent,
                    'MENO' => $username,
                    'PLATFORM' => $_SESSION['pla'],
                    'IP' => $_SESSION['ipa'],
                    'IPB' => $_SESSION['ipb'],
                    'ARCINTCIS' => ''
                );
                // $this->m_site->insert_data($data,'wuzivlogfake');

                redirect(base_url().'uvod?msg=faillogin');
            }
        } else {
            $this->load->view('login');
        }
    }
}