<?php

class C_uri extends CI_Controller {

    function __construct() {
        parent::__construct();
        //kontrola prihlasenia
        if($this->session->userdata('status') != 'login'){
            redirect(base_url().'uvod?msg=nologin');
        }
        $this->load->library(array('user_agent', 'custom_library'));
    }

    function index() {

        if($this->agent->is_browser()){
            //echo "<h3>Browser name: ".$this->agent->browser().", Version: ".$this->agent->version()."</h3>";
            $agent = "<h3>Browser name: ".$this->agent->browser().", Version: " . $this->agent->version()."</h3>";
        }elseif ($this->agent->is_robot())
        {
            $agent = $this->agent->robot();
        }elseif($this->agent->is_mobile()){
            //echo $this->agent->mobile();
            $agent = $this->agent->mobile();
        }else{$agent = 'Unidentified User Agent';}
        
        echo $agent;  
        echo "<br/>" . $this->agent->platform();

        //echo "<br/>" . $this->uri->segment(1, 'No segment exists');
    }    

    function my_segments(){
        echo $this->uri->segment(1, 'No segment exists');
    }

    function run_custom_library_fn(){

        echo $this->custom_library->my_upper_case('333 stribrnych strikacek strikalo pres 333 stribrnych strech') .  "<br/>" ;

        echo "<br/>" . $this->custom_library->my_base_url();

    }
}
?>