<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'c_site';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['home'] = 'c_site/index';
$route['login'] = 'login';
$route['logout'] = 'c_site/logout';

$route["site/about-info"] = "c_site/about";
$route["site/contact"] = "c_site/contact_info";
$route["site/product/(:num)"] = "c_site/product/$1";
$route["site/service/(:num)/(:any)"] = "c_site/service/$1/$2";
$route["site/variable"] = "c_site/pass_var";

$route["site/insert-data"] = "c_site/insert_data_into_table";

$route["action/select-all"] = "c_action/get_all_data";
$route["action/update-data"] = "c_action/update_data";

$route["action/salary-filter"] = "c_action/condition";
$route["action/messages"] = "c_action/get_messages";

$route["helpers/form"] = "c_user/form_helper_study";
$route["helpers/form-submit"] = "c_uziv/form_submit_method";
$route["users/list"] = "c_user/list_users";
$route["action/users"] = "c_action/get_users";
$route["action/delete-single"] = "c_action/delete_single_user";
$route["uziv/list"] = "c_uziv/list";
$route["uziv/hesla"] = "c_uziv/pandasranda";

$route["ria/iso"] = "c_ria/list_iso";
$route["ria/ttp"] = "c_ria/list_ttp";
$route["ria/cer"] = "c_ria/list_cer";

$route["posta/list"] = "c_posta/list";
$route["posta/listz"] = "c_posta/listz";
$route["posta/posta"] = "c_posta/form_posta";
$route["posta/list_zmen"] = "c_posta/listz";

$route["doch/list"] = "c_doch/list";
$route["doch/mes"] = "c_doch/mes_doch";
$route["doch/mesa"] = "c_doch/mesa";
$route["doch/preh"] = "c_doch/prehlad";
$route["doch/rozjb"] = "c_doch/jb_rozpis";
$route["doch/rozhr"] = "c_doch/hr_rozpis";

$route["about"] = "c_site/about";

$route["kalkul/list"] = "c_kalkul/list";
$route["ulohy/list"] = "c_ulohy/list";
$route["ulohy/last"] = "c_ulohy/last";
$route["ulohy/rep"] = "c_ulohy/rep";

$route["zakazky/list"] = "c_zakazky/index";
$route["zakazky/lista"] = "c_zakazky/index";
$route["zakazky/listx"] = "c_zakazky/listx";
$route["zakazky/hlist"] = "c_zakazky/hlist";
$route["zakazky/zakazka"] = "zobraz/zakazka";
$route["zakazky/dopyt"] = "c_zakazky/zakdopyt";
$route["zakazky/oprav"] = "c_zakazky/oprav_dia_zakazky";
$route["zakazky/updatezak"] = "c_zakazky/update_data";
$route["zakazky/emptyzak"] = "c_zakazky/empty_zakazky";

$route["upload-form"] = "c_upload/my_upload_form";
$route["upload-files"] = "c_upload/upload_my_files";

$route["my-uri"] = "c_uri";
$route["my-segment"] = "c_uri/my_segments";
$route["custom-library"] = "c_uri/run_custom_library_fn";

$route["form-helpers"] = "c_helpers/form_helpers";