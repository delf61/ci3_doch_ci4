<?php

    $this->load->view("include/header") ?>
    
    <form action="<?php echo site_url('submit-form-data') ?>" method="post" class="" id="" enctype="multipart/form-data">


    </form>

    <?php 
        // echo form_open('zakazky/updatezak', '', $hidden);

    ?>







    
    <!-- Footer section -->
    <?php
        $this->load->view("include/footer");
    ?>

    </body>
</html> 