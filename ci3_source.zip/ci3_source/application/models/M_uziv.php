<?php
class M_uziv extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('directory');
        $this->load->helper('file');
    }
    function get_all() {
        $this->db->select("*");
        $this->db->where("id<>", 1);
        $this->db->where("id<>", 10);
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_1($id) {
        $this->db->select("*");
        $this->db->where("id", $id);
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function sav_cel($data,$i){
        $this->db->where("id", $i);
        $this->db->update("_uzivatelia", $data);
    }
    function get_list($a,$s) {
        $this->db->select("id, PRACE_MENO as MENO, KOD");
        //$this->db->select("*");
        if($a==1){$this->db->where("AKTUALNY =", 1);}else{$this->db->where("AKTUALNY =", 0);};
        if($s=='h'){$this->db->where("substr(SKUPINA,1,2)!=", 'JB');};
        if($s=='j'){$this->db->where("substr(SKUPINA,1,2)=", 'JB');};
        $this->db->where("KOD!=", 0);
        $this->db->where("KOD!=", 9999);
        $this->db->order_by('MENO', 'ASC');
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_listh($a,$s) {
        $this->db->select("id, PRACE_MENO as MENO, KOD, ARCINTCIS");
        //$this->db->select("*");
        if($a==1){$this->db->where("AKTUALNY =", 1);}else{$this->db->where("AKTUALNY =", 0);};
        if($s=='h'){$this->db->where("substr(SKUPINA,1,2)!=", 'JB');};
        if($s=='j'){$this->db->where("substr(SKUPINA,1,2)=", 'JB');};
        $this->db->where("KOD!=", 0);
        $this->db->where("KOD!=", 9999);
        $this->db->order_by('MENO', 'ASC');
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_list1($a) {
        $this->db->select("*");
        $this->db->where("KOD =", $a);
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_login($d) {
        $this->db->select("*");
        $this->db->order_by('DATUM,OD', 'DESC');
        if($d!=null){
            if($d!='..'){$this->db->where("DATUM", $d);}
        }
        $data=$this->db->get('wuzivlog');
        return $data->result();
    }
    function get_last_login($k,$d,$i,$ib,$p) {
        $r = substr(date("Y"), 2, 2);
        $query = $this->db->query("SELECT id,DATUM,OD FROM wuzivlog WHERE id_user=".$k." AND DATUM='".$d."' AND IP='".$i."' AND IPB='".$ib."' AND PLATFORM='".$p."' order by DATUM,OD DESC");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->id;};
    }
    function upd_log($data,$i){
        $this->db->where("id", $i);
        $this->db->update('wuzivlog', $data);
    }
    function get_skup_prac($k) {
        $query = $this->db->query("SELECT SKUPINA FROM _uzivatelia WHERE KOD=".$k."");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->SKUPINA;};
    }
    function get_poz_prac($k) {
        $query = $this->db->query("SELECT POZICIA FROM _uzivatelia WHERE KOD=".$k."");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->POZICIA;};
    }
    function get_gen_list(){
        $this->db->select("id,KOD,HESO");
        //$this->db->where("KOD!=", 0);
        $this->db->where("KOD!=", 9999);
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_arezia_1($k){
        $this->db->select("id,KOD,MENO,OS_CISLO");
        $this->db->where("KOD=", $k);
        $this->db->where("CAST =", 81);
        $this->db->where("DATUM=", date('d.m.Y'));
        $data=$this->db->get('wdochzak');
        return $data->result();
    }
    function get_arezia_uz($k){
        $this->db->select("id");
        $this->db->where("KOD=", $k);
        $this->db->where("AKTUALNY =", 1);
        $this->db->where("AUTO_REZIA=", 1);
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_aktu() {
        $prio = $this->session->userdata('prio');
        if($prio>6){} 
        elseif($prio==6){$this->db->where("substr(SKUPINA,1,2)=", 'JB');}
        else{$this->db->where('kod=', $this->session->userdata('kod'));}
        $this->db->select("id, PRACE_MENO as MENO, KOD");
        $this->db->where("AKTUALNY =", 1);
        $this->db->where("KOD!=", 0);
        $this->db->where("KOD!=", 9999);
        $this->db->order_by('MENO', 'ASC');
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_prirad() {
        $this->db->select("id, PRACE_MENO as MENO, KOD");
        $this->db->where("AKTUALNY=", 1);
        $this->db->where("KOD_PRACE=", $this->session->userdata('kod'));
        $this->db->or_where("KOD_PRACE1", $this->session->userdata('kod'));
        $this->db->or_where("KOD_PRACE2", $this->session->userdata('kod'));
        $this->db->or_where("KOD_PRACE3", $this->session->userdata('kod'));
        $this->db->or_where('kod=', $this->session->userdata('kod'));
        $this->db->order_by('MENO', 'ASC');
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_valid() {
        $this->db->where("AKTUALNY =", 1);
        $this->db->where("VALIDACIA =", 1);
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_zodpo() {
        $prio = $this->session->userdata('prio');
        $this->db->where("SKUPINA =", 'vedenie');
        //if($prio>8){$this->db->or_where("SKUPINA =", 'admin');};
        $this->db->or_where("SKUPINA =", 'THP');
        $this->db->or_where("SKUPINA =", 'JB THP');
        $this->db->where("AKTUALNY =", 1);
        $this->db->order_by('PRACE_MENO', 'ASC');
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_u2() {
        $this->db->select("KOD,PRACE_MENO");
        $this->db->where("PRIORITA", 2);
        $this->db->order_by('PRACE_MENO', 'ASC');
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_skup() {
        $this->db->select("*");
        $this->db->where("KOD_SKU!=", 99);
        $data=$this->db->get('_uziv_skup');
        return $data->result();
    }
    function get_skup_uziv($s,$p) {
        $this->db->select("*");
        $this->db->where("SKUPINA", $s);
        $this->db->where("POZICIA", $p);
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_uziv_skup() {
        $this->db->select("SKUPINA,POZICIA");
        $this->db->where("SKUPINA!=", 'admin');
        $this->db->where("SKUPINA!=", '');
        $this->db->where("POZICIA!=", 'JB');
        $this->db->group_by("SKUPINA,POZICIA");
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_uziv_skup_hr() {
        $this->db->select("SKUPINA,POZICIA");
        $this->db->where("SKUPINA!=", 'admin');
        $this->db->where("SKUPINA=", 'výroba');
        $this->db->group_by("SKUPINA,POZICIA");
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_skupt($skup) {
        $query = $this->db->query("SELECT SKUPINA FROM _uziv_skup WHERE KOD_SKU=".$skup.";");
        $row = $query->row();
        return $row->SKUPINA;
    }
    function get_uzivt($uziv) {
        $query = $this->db->query("SELECT MENO FROM _uzivatelia WHERE KOD=".$uziv.";");
        $row = $query->row();
        return $row->MENO;
    }
    function get_kod($s) {
        if($s=='h'){$query = $this->db->query("SELECT KOD FROM _uzivatelia WHERE KOD<900 ORDER BY KOD DESC LIMIT 1;");};
        if($s=='j'){$query = $this->db->query("SELECT KOD FROM _uzivatelia WHERE KOD>1000 AND KOD<1100 ORDER BY KOD DESC LIMIT 1;");};
        $row = $query->row();
        //if (isset($row)){echo $row->KOD;}; 
        return $row->KOD;
    }
    function get_kod_fr_meno($m) {
        $query = $this->db->query("SELECT KOD FROM _uzivatelia WHERE MENO='" . $m . "' LIMIT 1;");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->KOD;};
    }
    function get_all_meso($i) {
        $query = $this->db->query("SELECT * FROM _uzivatelia WHERE id !=".$i.";");
        $array = array();
        foreach($query->result_array() as $row){
            if($_SESSION['ae']=='a'){
                //if($row['id'!=$i]){
                    $array[] = $row['MESO']; // add each MESO to the array
                //}
            }
        }
        return $array;
    }
    function get_all_meno($i) {
        $query = $this->db->query("SELECT * FROM _uzivatelia WHERE id !=".$i.";");
        $array = array();
        foreach($query->result_array() as $row){
            if($_SESSION['ae']=='a'){
                //if($row['id'!=$i]){
                    $array[] = $row['MESO']; // add each MESO to the array
                //}
            }
        }
        return $array;
    }
    function get_all_osc($i) {
        $query = $this->db->query("SELECT * FROM _uzivatelia WHERE id !=".$i.";");
        $array = array();
        foreach($query->result_array() as $row){
            if($_SESSION['ae']=='a'){
                //if($row['id'!=$i]){
                    $array[] = $row['OS_CISLO'];
                //}
            }
        }
        return $array;
    }
    function get_iso() {
        $this->db->select("*");
        $data=$this->db->get('_uziv_iso');
        return $data->result();
    }
    function get_iso_uziv() {
        $this->db->select("KOD,ESO,MENO");
        $this->db->where("ESO<>", '');
        $data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_isot($iso) {
        $query = $this->db->query("SELECT ESO FROM _uziv_iso WHERE KOD_ISO=".$iso.";");
        $row = $query->row();
        return $row->ESO;
    }
    function del_uziv($z){
        $this->db->where("id", $z);
        $this->db->delete("_uzivatelia");
    }
    function del_Veno(){
        $this->db->where("MENO", 'Ing. Viera Vénosováaaaaaa');
        $this->db->delete("_uzivatelia");
    }
    function add_uziv($data){
        $this->db->insert('_uzivatelia', $data);
    }
    function upd_uziv($data,$i){
        $this->db->where("id", $i);
        $this->db->update("_uzivatelia", $data);
    }
    function upd_uziv_kod($data,$k){
        $this->db->where("kod", $k);
        $this->db->update("_uzivatelia", $data);
    }

    // $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Send-MailMessage -SmtpServer technos-sk.mail.protection.outlook.com -from isyt@technos.sk -To ' . $adr . ' -UseSsl $true -Subject \'import z omegy OK\'"';
    // $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Send-MailMessage -SmtpServer technos-sk.mail.protection.outlook.com -from isyt@technos.sk -To zakovic@aiten.sk -UseSsl $true -Subject \'test > mail z ISyTu cez powershell X\'"';

}
?>