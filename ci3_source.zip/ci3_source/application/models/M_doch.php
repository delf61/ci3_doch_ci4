<?php
class M_doch extends CI_Model {
    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('directory');
    }
    function get_all($d, $vypl) {
        $this->db->select("*");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->order_by('id_uziv,DAT', 'ASC');
        //$this->db->order_by('MENO', 'ASC');
        // $data=$this->db->from("wdoch");
        $prio = $this->session->userdata('prio');
        if($prio>0){
            //$this->db->join('_uzivatelia', "_uzivatelia.id = wdoch.id_uziv");
        }

        if($d == '01.01.2000'){
            $_SESSION['den'] = date('d.m.Y');
        } else {
            // $_SESSION['den'] = strtotime($d);
        }

        if($vypl == 'x'){        
            $data=$this->db->get("wdoch");
        } else {
            $data=$this->db->get("wdoch_vypl");
        }
        return $data->result();
    }

    function get_all_job_hours($d) {
        $this->db->select("*");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->where("PRICHOD<>", ' ');
        $data=$this->db->get("wdoch");
        return $data->result();
    }

    function get_odch($id){
        $query = $this->db->query("SELECT ODCHOD FROM wdoch_vypl WHERE id='" . $id . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->ODCHOD;};
    }
    function get_prich($id){
        $query = $this->db->query("SELECT PRICHOD FROM wdoch_vypl WHERE id='" . $id . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->PRICHOD;};
    }

    function get_spolu($i, $d) {
        $_SESSION['upd'] = 0;
        $query = $this->db->query("SELECT sum(HODINY) AS SPOLU FROM wdoch_vypl WHERE id='" . $i . "' AND substr(DATUM, 4, 7) = '" . $d . "';");
        $row = $query->row();
        if($row==null){$_SESSION['upd'] = 0;}else{$_SESSION['upd'] = $row->SPOLU;}
    }
    function get_1($i, $vypl) {
        $_SESSION['upd'] = 0;
        $this->db->select("*");
        $this->db->where("substr(DATUM, 4, 7)=", date('m.Y', $_SESSION['den']));
        $this->db->where("id_uziv", $i);
        $this->db->order_by('DAT', 'ASC');
        if($vypl == 'x'){
            $data=$this->db->get("wdoch");
        } else {
            $data=$this->db->get("wdoch_vypl");
        }
        return $data->result();
    }
    
    
    function get_tlac() {
        $this->db->select("*");
        // $this->db->where("substr(DATUM, 4, 7)=", date('m.Y', $_SESSION['den']));
        // $this->db->where("id_uziv", $i);
        $this->db->order_by('DAT', 'ASC');
        $data=$this->db->get("wdoch_tlac");
        return $data->result();
    }
    function get_akt_den($id) {
        $this->db->select("DEN,SVIATOK");
        $this->db->where("id=", $id);
        $data=$this->db->get("wdoch");
        return $data->result();
    }
    function get_1_den($d, $i) {
        $this->db->select("id,DATUM,OD,DO,id_miesto,POZN,HODINY");
        $this->db->where("DATUM = ", $d);
        $this->db->where("id_uziv", $i);
        $this->db->order_by('OD', 'ASC');
        $data=$this->db->get("wdochhod");
        return $data->result();
    }
    function get_id_den($d, $id_uziv) {
        $this->db->select("id_miesto,OD,DO,HODINY");
        $this->db->where("DATUM=", $d);
        $this->db->where("id_uziv=", $id_uziv);
        $this->db->order_by('OD', 'ASC');
        $data=$this->db->get("wdochhod");
        return $data->result();
    }

    function get_mes_vypl($id_uziv){
        $this->db->select("*");
        // $this->db->where("DATUM=", $d);
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->where("id_uziv=", $id_uziv);
        $data=$this->db->get("wvypl_hod");
        return $data->result();
    }
    function add_mes_vypl($data){
        $this->db->insert('wvypl_hod', $data);
    }
    function upd_mes_vypl($data, $id){
        $this->db->where("id", $id);
        $this->db->update('wvypl_hod', $data);
    }

    function add_1_den_1_prac($data){
        $this->db->insert('wdoch', $data);
        $this->db->insert('wdoch_vypl', $data);
    }
    function add_1_den_1_prac_tlac($data){
        $this->db->insert('wdoch_tlac', $data);
    }
    function upd_1_den_1_prac_tlac($data, $i){
        $this->db->where("id", $i);
        $this->db->update('wdoch_tlac', $data);
    }
    function sav_cel($data,$i){
        $this->db->where("id", $i);
        $this->db->update("wdoch_vypl", $data);
    }
    function upd_doch($data, $id_u, $vp){
        $this->db->where("id_uziv", $id_u);
        $this->db->where("DATUM", $vp);
        $this->db->update("wdoch", $data);
        $this->db->update("wdoch_vypl", $data);
    }
    function upd_doch_vypl($data, $den_id){
        $this->db->where("id", $den_id);
        $this->db->update("wdoch_vypl", $data);
    }
    function get_doch_den() {
        $this->db->select("id, MENO, KOD");
        $this->db->distinct('MENO');
        //$this->db->group_by('MENO');
        $this->db->where("DATUM =", date("d.m.Y", $_SESSION['den']));
        $this->db->order_by('MENO', 'ASC');
        $data=$this->db->get("wdoch");
        $a = $data->num_rows();
        return $data->result();
    }
    function get_uziv_data($id){
        $this->db->select("*");
        $this->db->where("id =", $id);
        $this->db->from("_uzivatelia");
        $data=$this->db->get();
        // echo "<pre>";
        // print_r($data);
        // echo "</pre>";
        return $data->result();
    }
    function get_den_uzi_vypl($den,$id_u){
        $this->db->select("id, DEN, SVIATOK");
        $this->db->where("DATUM =", $den);
        $this->db->where("id_uziv", $id_u);
        $this->db->from("wdoch_vypl");
        $data=$this->db->get();
        return $data->result();
    }
    function get_mie_data($id){
        $this->db->select("*");
        $this->db->where("id =", $id);
        $this->db->from("wmiesta");
        $data=$this->db->get();
        // echo "<pre>";
        // print_r($data);
        // echo "</pre>";
        return $data->result();
    }
    function get_cin_data($id){
        $this->db->select("*");
        $this->db->where("id =", $id);
        $this->db->from("wcinnosti");
        $data=$this->db->get();
        // echo "<pre>";
        // print_r($data);
        // echo "</pre>";
        return $data->result();
    }
    function add_hod($data){
        $this->db->insert('wdochhod', $data);
    }
    function upd_hod($data, $id){
        $this->db->where("id", $id);
        $this->db->update("wdochhod", $data);
    }
    function upd_den_1_prac($data, $id){
        $this->db->where("id", $id);
        $this->db->update("wdoch", $data);
    }
    function upd_den_1_prac_pozn($id_uziv, $id, $data){
        $this->db->where("id_uziv", $id_uziv);
        $this->db->where("id", $id);
        $this->db->update("wdoch", $data);
    }
    function del_hod($id){
        $this->db->where("id", $id);
        $this->db->delete("wdochhod");
    }
    function kontroluj_hod($d) {
        $this->db->select("id,id_uziv,OD,DO,HODINY");
        $this->db->where("DATUM=", $d);
        $this->db->where("OD<>", ' ');
        $data=$this->db->get("wdochhod");
        return $data->result();
    }


    
    function get_doch() {
        $this->db->select("id, MENO, KOD");
        $this->db->distinct('MENO');
        //$this->db->group_by('MENO');
        $this->db->where("DATUM =", date("d.m.Y", $_SESSION['den']));
        $this->db->order_by('MENO', 'ASC');
        $data=$this->db->get("wdochzak");
        $a = $data->num_rows();
        return $data->result();
    }



    function get_mes($z,$p,$c,$m){
        $prio = $this->session->userdata('prio');
        if($prio==2){
            $this->load->dbforge();
            $this->dbforge->add_field("KOD float NOT NULL DEFAULT 0");
            $this->dbforge->add_field("KOD_PRACE float NOT NULL DEFAULT 0");
            $this->dbforge->add_field("KOD_PRACE1 float NOT NULL DEFAULT 0");
            $this->dbforge->add_field("KOD_PRACE2 float NOT NULL DEFAULT 0");
            $this->dbforge->add_field("KOD_PRACE3 float NOT NULL DEFAULT 0");
            $this->dbforge->create_table('z_uziv_pom_'.$this->session->userdata('kod'), TRUE);
            $this->db->truncate('z_uziv_pom_'.$this->session->userdata('kod'));
            $this->db->select("KOD");
            $this->db->where('KOD', $this->session->userdata('kod'));
            $this->db->or_where('KOD_PRACE', $this->session->userdata('kod'));
            $this->db->or_where('KOD_PRACE1', $this->session->userdata('kod'));
            $this->db->or_where('KOD_PRACE2', $this->session->userdata('kod'));
            $this->db->or_where('KOD_PRACE3', $this->session->userdata('kod'));
            $query = $this->db->get('_uzivatelia');
            // print_r("<br>"."<br>"."<br>"."<br>".'   '.$this->session->userdata('kod'));
            // print_r($query);
            $sub = 'z_uziv_pom_'.$this->session->userdata('kod');
            foreach ($query->result() as $row) {
                $data = array('KOD'=>$row->KOD //, 'KOD_PRACE'=>$row->KOD
                );
                $this->m_site->insert_data($data, $sub);
            }
        }
        $this->db->select("*");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        if($prio==6){$this->db->where("OS_CISLO =", 1);}else{
            if($z=='h'){$this->db->where("OS_CISLO !=", 1);};
            if($z=='j'){$this->db->where("OS_CISLO =", 1);};
        };
        if($p==0){}else{$this->db->where("wdochzak.KOD", $p);};
        if($c!=null){
            if($c=='00'){}else{$this->db->where("CAST", $c);};
        }
        if($m=='0'){$this->db->where("substr(CAST, 1, 1) <>", '9');}
        //$this->db->order_by('DATUM', 'ASC');
        //$this->db->order_by('MENO', 'ASC');
        $data=$this->db->from("wdochzak");
        if($prio==2){
            $this->db->join('z_uziv_pom_'.$this->session->userdata('kod'), "z_uziv_pom_".$this->session->userdata('kod').".KOD = wdochzak.KOD");
        }
        $data=$this->db->get();
        return $data->result();
    }
    function get_mes_prac(){
        $prio = $this->session->userdata('prio');
        $this->db->select('wdochzak.KOD,wdochzak.MENO');
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->group_by('wdochzak.KOD,wdochzak.MENO');
        $this->db->order_by("wdochzak.MENO",'ASC');
        $data=$this->db->from("wdochzak");
        if($prio==2){
            $this->db->join('z_uziv_pom_'.$this->session->userdata('kod'), "z_uziv_pom_".$this->session->userdata('kod').".KOD = wdochzak.KOD");
        }
        $data=$this->db->get();
        return $data->result();
    }
    function get_mes_cast(){
        $this->db->select('CAST,CAST_POPIS');
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->where("CAST<>", '');
        $this->db->group_by('CAST,CAST_POPIS');
        $this->db->order_by("CAST_POPIS",'ASC');
        $data=$this->db->get('wdochzak');
        return $data->result();
    }
    function get_mes_cinn(){
        $this->db->select('CAST_POPIS');
        $this->db->select_sum("TRVANIE");
        $this->db->where("TRVANIE>", 0);
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->group_by('CAST_POPIS');
        $this->db->order_by("TRVANIE",'DESC');
        $data=$this->db->get('wdochzak');
        return $data->result();
    }
    function get_mes_zaka(){
        $this->db->select('CISZAK');
        $this->db->select_sum("TRVANIE");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->group_by('CISZAK');
        $this->db->order_by("TRVANIE",'DESC');
        $data=$this->db->get('wdochzak');
        return $data->result();
    }
    function get_mes_zakl(){
        $this->db->select('CISZAK');
        $this->db->select_sum("TRVANIE");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->where("CISZAK<>", '');
        $this->db->group_by('CISZAK');
        $this->db->order_by("TRVANIE",'DESC');
        $data=$this->db->get('wdochzak');
        return $data->result();
    }
    function get_mes_1(){
        $this->db->select("*");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', $_SESSION['den']));
        $this->db->where("KOD =", $_SESSION['kod']);
        $this->db->order_by('DATUM', 'ASC');
        $this->db->order_by('MENO', 'ASC');
        $data=$this->db->get("wdochzak");
        return $data->result();
    }
    function get_fin($d,$z){
        $this->db->select("*");
        $this->db->where("D =", $d);
        $x = (int)$z;
        if($x>0){$this->db->where("KOD =", $x);};
        $prio = $this->session->userdata('prio');
        // if($prio==2 && $x==0){
        //     $this->db->distinct("d");
        // }
        if($prio==6){
            // $this->db->from('wfingera');
            // $this->db->join('_uzivatelia', '_uzivatelia.kod = wfingera.kod');
            // $this->db->where("POZICIA =", 'JB');
            // $data=$this->db->get();
            $this->db->where("AKYDEN =", 'JB');
        };
        $this->db->from('wfingera');
        if($prio==2 && $x==0){
        //    $this->db->join('_uzivatelia', "_uzivatelia.KOD_PRACE = ".$this->session->userdata('kod'));
        }
        $data=$this->db->get();
        return $data->result();
    }
    function get_prac($d,$z){
        $this->db->select("*");
        $this->db->where("DATUM =", $d);
        $x = (int)$z;
        $this->db->where("KOD =", $z);
        $this->db->from("wdochzak");
        $data=$this->db->get();
        // echo "<pre>";
        // print_r($data);
        // echo "</pre>";
        return $data->result();
    }
    function get_pracT($z){
        $this->db->select("*");
        $pom = substr($z, 0, 10);
        $this->db->where("DATUM =", substr($z, 0, 10));
        $prio = $this->session->userdata('prio');
        if($prio==6){$this->db->where("OS_CISLO =", 1);};
        $this->db->from('wdochzak');
        if($prio==2){
            $this->db->join('_uzivatelia', "_uzivatelia.KOD_PRACE = ".$this->session->userdata('kod'));
        }
        $data=$this->db->get();
        return $data->result();
    }
    function del_prac($z){
        $this->db->where("id", $z);
        $this->db->delete("wdochzak");
    }
    function add_prac($data){
        $this->db->insert('wdochzak', $data);
    }
    function upd_prac($data,$i){
        $this->db->where("id", $i);
        $this->db->update("wdochzak", $data);
    }
    function upd_prac_skup($q,$data){
        $this->db->where("KOD", $q);
        // $this->db->where("SKUPINA", '');
        // $this->db->or_where("SKUPINA", '');
        $this->db->update("wdochzak", $data);
    }
    function upd_zak_cast($z,$data){
        $this->db->where("CISZAK", $z);
        $this->db->update("wdochzak", $data);
    }
    function hod_get_zak_mes($z){
        $this->load->dbforge();
        $this->dbforge->add_field("DATUM varchar(7) NOT NULL DEFAULT ''");
        $this->dbforge->add_field("HODINY float NOT NULL DEFAULT 0");
        $this->dbforge->create_table('zak_prac_mes_'.$this->session->userdata('kod'), TRUE);
        $this->db->truncate('zak_prac_mes_'.$this->session->userdata('kod'));
        $this->dbforge->add_field("DATUM varchar(7) NOT NULL DEFAULT ''");
        $this->dbforge->add_field("SPOLU float NOT NULL DEFAULT 0");
        $this->dbforge->create_table('zak_obj_mes_'.$this->session->userdata('kod'), TRUE);
        $this->db->truncate('zak_obj_mes_'.$this->session->userdata('kod'));
        $this->dbforge->add_field("DATUM varchar(7) NOT NULL DEFAULT ''");
        $this->dbforge->add_field("SPOLU float NOT NULL DEFAULT 0");
        $this->dbforge->create_table('zak_pri_mes_'.$this->session->userdata('kod'), TRUE);
        $this->db->truncate('zak_pri_mes_'.$this->session->userdata('kod'));
        $this->dbforge->add_field("DATUM varchar(7) NOT NULL DEFAULT ''");
        $this->dbforge->add_field("SPOLU float NOT NULL DEFAULT 0");
        $this->dbforge->create_table('zak_vyd_mes_'.$this->session->userdata('kod'), TRUE);
        $this->db->truncate('zak_vyd_mes_'.$this->session->userdata('kod'));
        $this->dbforge->add_field("DATUM varchar(7) NOT NULL DEFAULT ''");
        $this->dbforge->add_field("SPOLU float NOT NULL DEFAULT 0");
        $this->dbforge->create_table('zak_obj_mes_gr_'.$this->session->userdata('kod'), TRUE);
        $this->db->truncate('zak_obj_mes_gr_'.$this->session->userdata('kod'));
        
        $this->db->select("DATUM");
        $this->db->group_by("substr(DATUM, 4, 7)");
        $this->db->where("CISZAK", $z);
        $this->db->order_by('DATUM');
        $pr=$this->db->get("wdochzak");
        return $pr->result();
    }
    function get_zak_mes_prac($z,$d){
        $this->db->select_sum("TRVANIE");
        $this->db->where("substr(DATUM, 4, 7) =", date('m.Y', strtotime($d)));
        $this->db->where("CISZAK", $z);
        $pr=$this->db->get("wdochzak");
        return $pr->result();
    }
    function get_hod_mes($t){
        $this->db->select("*");
        if($t==1){$this->db->order_by('DATUM','ASC');}else{$this->db->order_by('DATUM','DESC');}
        $pr=$this->db->get("zak_prac_mes_".$this->session->userdata('kod'));
        return $pr->result();
    }
    function obj_get_zak_mes($z){
        $this->db->select("DATOBJ");
        $this->db->group_by("substr(DATOBJ, 4, 7)");
        $this->db->where("CISZAK", $z);
        $this->db->order_by('DATOBJ','ASC');
        $pr=$this->db->get("wobjed");
        return $pr->result();
    }
    function get_zak_mes_obj($z,$d){
        $this->db->select_sum("SPOLU");
        $this->db->where("substr(DATOBJ, 4, 7) =", date('m.Y', strtotime($d)));
        $this->db->where("CISZAK", $z);
        $pr=$this->db->get("wobjed");
        return $pr->result();
    }
    function get_obj_mes($t){
        $this->db->select("*");
        if($t==1){$this->db->order_by('DATUM','ASC');}else{$this->db->order_by('DATUM','DESC');}
        $pr=$this->db->get("zak_obj_mes_".$this->session->userdata('kod'));
        return $pr->result();
    }
    function get_obj_mes_gr(){
        $this->db->select("*");
        $this->db->order_by('DATUM','ASC');
        $pr=$this->db->get("zak_obj_mes_gr_".$this->session->userdata('kod'));
        return $pr->result();
    }
    function pri_get_zak_mes($z){
        $this->db->select("DATPRI");
        $this->db->group_by("substr(DATPRI, 4, 7)");
        $this->db->where("CISZAK", $z);
        $this->db->order_by('DATPRI');
        $pr=$this->db->get("wprijemky");
        return $pr->result();
    }
    function get_zak_mes_pri($z,$d){
        $query = $this->db->query("SELECT sum(MNOZSTVO * CENA) AS SPOLU FROM wprijemky WHERE CISZAK='" . $z . "' and substr(DATPRI, 4, 7) = '" . $d . "';");
        //return $result = $query->result();
        $row = $query->row();
        if($row==null){return 0;}else{return $row->SPOLU;};
    }
    function get_pri_mes(){
        $this->db->select("*");
        $this->db->order_by('DATUM','DESC');
        $pr=$this->db->get("zak_pri_mes_".$this->session->userdata('kod'));
        return $pr->result();
    }
    function vyd_get_zak_mes($z){
        $this->db->select("DATVYD");
        $this->db->group_by("substr(DATVYD, 4, 7)");
        $this->db->where("CISZAK", $z);
        $this->db->order_by('DATVYD');
        $pr=$this->db->get("wvydajky");
        return $pr->result();
    }
    function get_zak_mes_vyd($z,$d){
        $query = $this->db->query("SELECT sum(MNOZSTVO * CENA) AS SPOLU FROM wvydajky WHERE CISZAK='" . $z . "' and substr(DATVYD, 4, 7) = '" . $d . "';");
        // return $result = $query->result();
        $row = $query->row();
        if($row==null){return 0;}else{return $row->SPOLU;};
    }
    function get_vyd_mes(){
        $this->db->select("*");
        $this->db->order_by('DATUM','DESC');
        $pr=$this->db->get("zak_vyd_mes_".$this->session->userdata('kod'));
        return $pr->result();
    }
    function prehlad_ini() {
        $this->load->dbforge();
        $this->dbforge->add_field("MENO varchar(30) NOT NULL DEFAULT ''");
        $this->dbforge->add_field("Z1 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z2 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z3 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z4 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z5 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z6 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z7 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z8 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z9 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z10 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z11 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z12 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z13 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z14 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z15 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z16 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z17 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z18 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z19 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z20 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z21 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z22 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z23 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z24 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z25 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z26 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z27 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z28 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z29 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z30 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("Z31 float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("SPOLU float NOT NULL DEFAULT 0");
        $this->dbforge->add_field("PROFESIA varchar(20) NOT NULL DEFAULT ''");
        $this->dbforge->create_table('skup_zak_'.$this->session->userdata('kod'), TRUE);
        $this->db->truncate('skup_zak_'.$this->session->userdata('kod'));
    }
    function add_prehlad($data) {
        $this->db->insert('skup_zak_'.$this->session->userdata('kod'), $data);
    }
    function get_prehlad() {
        $this->db->select("*");
        $data=$this->db->get('skup_zak_'.$this->session->userdata('kod'));
        return $data->result();
    }
    function get_skup_zak_zoznam($s,$po,$d,$r) {
        if($r==1){$this->load->dbforge();$this->db->truncate('skup_zak_'.$this->session->userdata('kod'));}
        $this->db->select("CISZAK");
        $this->db->where("SKUPINA", $s);
        if($po=='.'){$this->db->where("length(POZICIA)<",2);}else{$this->db->where("POZICIA", $po);}
        $this->db->where("CISZAK<>", '');
        $this->db->where("substr(DATUM, 4, 7)=", $d);
        $this->db->group_by("CISZAK");
        $data=$this->db->get('wdochzak');
        return $data->result();
    }
    function get_skup_uzi_zoznam($s,$po,$d) {
        $this->db->select("MENO");
        $this->db->where("SKUPINA", $s);
        //$this->db->where("AKTUALNY", 1);
        //$this->db->where("AUTO_REZIA", 0);
        if($po=='.'){$this->db->where("length(POZICIA)<",2);}else{$this->db->where("POZICIA", $po);}
        $this->db->where("substr(DATUM, 4, 7)=", $d);
        $this->db->group_by("MENO");
        $data=$this->db->get('wdochzak');
        //$data=$this->db->get('_uzivatelia');
        return $data->result();
    }
    function get_hod_uzi_zak($u, $d, $z){
        $query = $this->db->query("SELECT sum(TRVANIE) AS HOD FROM wdochzak WHERE CISZAK='" . $z . "' and substr(DATUM, 4, 7) = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
    function get_zak_uzi_zoznam($cz,$d) {
        $this->load->dbforge();$this->db->truncate('skup_zak_'.$this->session->userdata('kod'));
        $this->db->select("MENO");
        $this->db->where("CISZAK", $cz);
        $this->db->where("substr(DATUM, 4, 7)=", $d);
        $this->db->group_by("MENO");
        $data=$this->db->get('wdochzak');
        return $data->result();
    }
    function get_uzi_prof($u){
        $query = $this->db->query("SELECT PROFESIA FROM _uzivatelia WHERE PRACE_MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return '';}else{return $row->PROFESIA;};
    }
    function get_hod_den_uzi_zak($u, $d, $z){
        $query = $this->db->query("SELECT sum(TRVANIE) AS HOD FROM wdochzak WHERE CISZAK='" . $z . "' and DATUM = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
    function get_hod_den_uzi($u, $d){
        $query = $this->db->query("SELECT TRVANIE AS HOD FROM wdochzak WHERE DATUM = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
    function get_sum_hod_den_uzi($u, $d){
        $query = $this->db->query("SELECT sum(TRVANIE) AS HOD FROM wdochzak WHERE DATUM = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
    function get_hod_uzi_rezia($u, $d){
        $query = $this->db->query("SELECT sum(TRVANIE) AS HOD FROM wdochzak WHERE CAST='81' and substr(DATUM, 4, 7) = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
    function get_hod_uzi_doprava($u, $d){
        $query = $this->db->query("SELECT sum(TRVANIE) AS HOD FROM wdochzak WHERE CAST='82' and substr(DATUM, 4, 7) = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
    function get_hod_uzi_rekon($u, $d){
        $query = $this->db->query("SELECT sum(TRVANIE) AS HOD FROM wdochzak WHERE CAST='83' and substr(DATUM, 4, 7) = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
    function get_hod_uzi_udrzba($u, $d){
        $query = $this->db->query("SELECT sum(TRVANIE) AS HOD FROM wdochzak WHERE CAST='84' and substr(DATUM, 4, 7) = '" . $d . "' and MENO = '" . $u . "';");
        $row = $query->row();
        if($row==null){return 0;}else{return $row->HOD;};
    }
}
?>