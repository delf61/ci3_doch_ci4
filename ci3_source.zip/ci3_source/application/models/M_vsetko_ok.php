<?php 
  class M_vsetko_ok extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('directory');
        $this->load->helper('file');
    }

    function mail_vsetko_ok(){
      // $adr = 'delfsasa@gmail.com';

      // $config = array(
      //     'protocol' => 'smtp',
      //     'smtp_host' => 'pop.gmail.com',
      //     'smtp_port' => '995',
      //     'smtp_crypto' => 'tls',
      //     'smtp_user' => 'delpharmsro@gmail.com',
      //     'smtp_pass' => 'He$lo.123'
      // );
      // $this->load->library('email', $config);
      
      // // $this->email->initialize($config);

      // $this->email->clear();

      // $this->email->from('delpharmsro@gmail.com');
      // $this->email->to($adr);
      // // $this->email->cc('another@another-example.com');
      // // $this->email->bcc('them@their-example.com');
      // $this->email->subject('webDoch > všetko OK ;-)');
      // $this->email->message('');

      // $this->email->send();

      $adr = "betinavonhostie@zoznam.sk";
      $subor = "C:\\backup\\doch.sql.gz";
      $appPass = "mzen oodo ilnu zciz";

      $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Send-MailMessage -From delpharmsro@gmail.com -To ' . $adr . ' -Subject \'import z omegy OK\' -Body \'Hotovo\' -SmtpServer smtp.gmail.com -Port 587 -UseSsl -Credential (New-Object System.Management.Automation.PSCredential(\'delpharmsro@gmail.com\', (ConvertTo-SecureString \'' . $appPass . '\' -AsPlainText -Force))) -Attachments \'' . $subor . '\' "';

      // $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Send-MailMessage -SmtpServer technos-sk.mail.protection.outlook.com -from isyt@technos.sk -To ' . $adr . ' -UseSsl $true -Subject \'import z omegy OK\'"';
      // $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Send-MailMessage -SmtpServer technos-sk.mail.protection.outlook.com -from isyt@technos.sk -To zakovic@aiten.sk -UseSsl $true -Subject \'test > mail z ISyTu cez powershell X\'"';

    }
  }
?>