<?php

    class Custom_library{

        public $ci;

        function __construct() {

            $this -> ci =& get_instance();
            //$CI =& get_instance();            
        }

        function my_upper_case($string){

            return strtoupper($string);
        }
        
        function my_base_url(){
            
            $this -> ci -> load -> helper("url");
            return base_url();
        }

        function my_session_store($value){
            
            $this -> ci -> load -> library("session");
            $this -> ci -> session -> set_postdata( "name", $value );
            
        }

        function my_session_get($key){
            
            $this -> ci -> load -> library("session");
            $this -> ci -> session -> set_postdata( "name", $value );
            
        }
    }
?>