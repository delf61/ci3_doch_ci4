<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Uvod::index');
$routes->match(['get', 'post'], 'action/users', 'C_action::get_users');
$routes->match(['get', 'post'], 'uvod', 'Uvod::index');
$routes->match(['get', 'post'], 'uvod_t', 'Uvod_t::index');
$routes->match(['get', 'post'], 'login', 'Uvod::login');
$routes->match(['get', 'post'], 'action/select-all', 'C_action::get_all_data');
$routes->match(['get', 'post'], 'site/about-info', 'C_site::about');
$routes->match(['get', 'post'], 'uvod/login', 'Uvod::login');
